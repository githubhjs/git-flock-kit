package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/stricttools/safegit/internal/conflict"
	"github.com/stricttools/safegit/internal/exitcode"
	"github.com/stricttools/safegit/internal/git"
	"github.com/stricttools/safegit/internal/gitexec"
	"github.com/stricttools/safegit/internal/repo"
	"github.com/stricttools/safegit/internal/sequencer"
	"github.com/stricttools/strictcli/go/strictcli"
)

// `safegit cherry-pick <commit>`, restructured.
//
// As a plain passthrough, GIT authored whatever commits came out of the
// operator's command line: they carried none of safegit's trailers, safegit's
// commit-time machinery never ran, `safegit undo` could not reverse them, and
// git's own operation state was left in the git directory for the next
// `safegit commit` to refuse over.
//
// The restructure splits the operation where git itself splits it, exactly as
// the restructured merge and revert do: `git cherry-pick --no-commit` COMPUTES
// the pick and stages its result, and the conclusion engine (the one behind
// `safegit cherry-pick-continue`) turns that staged result into a commit --
// pipeline-authored, trailers injected, commit-msg hook run, ref moved under
// compare-and-swap, state files removed. The AUTHOR is preserved from the
// commit being applied and the committer is whoever ran the command, which is
// git's own division and not a safegit policy.
//
// THE PARK FILE is what this restructure needed and the revert's did not.
// `git cherry-pick --no-commit` records NOTHING about the commit it is
// applying: no CHERRY_PICK_HEAD, on the clean path or the conflicted one (git
// writes that file only when git is going to make the commit itself). Every
// piece of machinery around a parked pick keys on it -- the conclusion's own
// state read, the preserved identity, the per-path conflict listing, `git
// status`, `git cherry-pick --abort`. So safegit writes it after the compute
// step, uniformly on both paths, through sequencer.MarkCherryPick. The parked
// state is then exactly what a conflicted pick looks like to git, and every
// existing path works on it unchanged.
//
// (`git revert --no-commit` DOES write REVERT_HEAD on both paths --
// probe-verified -- which is why revert_cmd.go never needed this. The park-file
// write is the pick's own addition, not a shared step.)
//
// The command line is narrower than git's, under the subset law -- see
// cherryPickSubset (subset_allowlist.go) and refuseUnsupportedCherryPick.

// runCherryPick dispatches `safegit cherry-pick`.
//
// Two routes stay passthroughs, and both for the same reason: they author
// nothing, so nothing about single authorship is at stake in them. They are NOT
// the same passthrough, and the difference is what each one asks git to do. The
// state-control verbs act on an operation git already has in flight and are the
// way out of it, so they carry the two worktree guards and nothing more.
// `--no-commit` asks git to COMPUTE the pick and stage it, which is the one
// thing that may not run over somebody else's parked operation -- so it goes
// through the computing door, which adds the in-flight entry refusal the
// restructured command already makes. `--continue` is refused inside, by name,
// because concluding a cherry-pick is safegit's own job.
func runCherryPick(flags globalFlags, args []string) int {
	parsed := parseGitArgs("cherry-pick", args)

	// The allowlist covers EVERY route, the state-control forms included: an
	// option safegit does not implement is refused whichever verb it accompanies.
	if code := cherryPickSubset.refuseUnsupportedOptions(flags, parsed); code != 0 {
		return code
	}
	if parsed.Has("--continue", "--abort", "--quit") {
		return runGuardedPassthrough(flags, "cherry-pick", args)
	}
	if parsed.Has("-n", "--no-commit") {
		return runComputingPassthrough(flags, "cherry-pick", args)
	}
	return runRestructuredCherryPick(flags, args, parsed)
}

// refuseUnsupportedCherryPick refuses the command lines safegit's cherry-pick
// does not implement, before any lock is taken and before any git runs.
//
// Every refusal is parser-shaped (exit 2) and names the capability that is
// absent, because "safegit does not do this" is a different answer from "this
// failed" and an operator has to be able to tell them apart. Each needs its
// entry in the divergences catalog.
func refuseUnsupportedCherryPick(flags globalFlags, parsed gitArgs) int {
	if len(parsed.AfterDoubleDash) > 0 {
		errorf(flags, "safegit cherry-pick takes no pathspec\n"+
			"  a pathspec applies part of a commit and records a message claiming the whole of it.\n"+
			"  Pick the commit, or make the partial change yourself and commit it.")
		return exitcode.Usage
	}

	// BEFORE the count, because a rev-set is one argv token and counting tokens
	// would call `main..side` a single commit.
	for _, rev := range parsed.Revisions {
		if code := refuseRevisionSet(flags, "cherry-pick", rev); code != 0 {
			return code
		}
	}

	switch len(parsed.Revisions) {
	case 1:
	case 0:
		errorf(flags, "safegit cherry-pick names no commit to pick\n"+
			"  usage: safegit cherry-pick <commit>")
		return exitcode.Usage
	default:
		errorf(flags, "safegit cherry-pick takes exactly one commit, and this names %d\n"+
			"  %s", len(parsed.Revisions), sequentialFormReason("cherry-pick"))
		return exitcode.Usage
	}
	return 0
}

// refuseRevisionSet refuses a revision argument that is a RANGE or another
// rev-set spelling rather than the name of one commit.
//
// It is a refusal on the OPERATORS rather than on how many arguments were
// typed, and that is the whole point: `git cherry-pick A..B` hands the
// operation to git's sequencer -- queue directory and all -- even where the
// range holds a single commit (probed). A check that counted argv tokens would
// let exactly that command line through as "one commit".
//
// DIVERGENCE: git's cherry-pick and revert take the full revision-set grammar;
// safegit's take the name of one commit. Cataloged in docs/divergences.md as
// "One commit per cherry-pick, one per revert; ranges are refused".
func refuseRevisionSet(flags globalFlags, verb, rev string) int {
	var operator string
	switch {
	case strings.Contains(rev, "..."):
		operator = "..."
	case strings.Contains(rev, ".."):
		operator = ".."
	case strings.HasPrefix(rev, "^"):
		operator = "a leading ^"
	case strings.HasSuffix(rev, "^!"):
		operator = "^!"
	case strings.HasSuffix(rev, "^@"):
		operator = "^@"
	default:
		return 0
	}

	errorf(flags, "safegit %s does not take a commit range or a revision set (%q uses %s)\n"+
		"  a range puts git's own sequencer in charge -- it queues the commits and authors every\n"+
		"  commit it makes -- and it does so even where the range holds a single commit.\n"+
		"  %s", verb, rev, operator, sequentialFormReason(verb))
	return exitcode.Usage
}

// sequentialFormReason is the one sentence that says what to do instead of
// naming several commits, spelled once so cherry-pick and revert say the same
// thing.
//
// DIVERGENCE: git applies any number of commits in one invocation; safegit
// applies one. Cataloged in docs/divergences.md as "One commit per cherry-pick,
// one per revert; ranges are refused" (the same entry as the rev-set refusal).
func sequentialFormReason(verb string) string {
	return fmt.Sprintf("safegit %s applies ONE commit and authors the result itself; run it once per commit, in the order you want them applied. See docs/divergences.md.", verb)
}

// runRestructuredCherryPick is the whole flow.
func runRestructuredCherryPick(flags globalFlags, args []string, parsed gitArgs) int {
	// FIRST, and before the repository is touched at all: a command line
	// safegit itself refuses is refused without a lock, without an
	// auto-initialization and without a git call.
	if code := refuseUnsupportedCherryPick(flags, parsed); code != 0 {
		return code
	}

	gitDir := mustGitDir()
	if err := ensureInitialized(flags, gitDir); err != nil {
		errorf(flags, "%v", err)
		return exitcode.NotInitialized
	}
	sgDir := repo.SafegitDir(gitDir)

	// A pick concluded in a submodule moves the parent's gitlink exactly as an
	// ordinary commit does, so the parent must have answered the auto-bump
	// question before anything is written.
	if err := requireAutoBumpDecision(flags.ctx(), flags); err != nil {
		errorf(flags, "auto-bump parent: %v", err)
		return exitcode.General
	}

	release, code := acquireOperationLock(flags, gitDir, "cherry-pick")
	if code != 0 {
		return code
	}
	defer release()

	if code := coordGuard(flags, gitDir, "cherry-pick"); code != 0 {
		return code
	}

	// Before the compute, and inside the operation lock: a pick may not be
	// computed over an operation git already has in flight. The compute step is
	// `cherry-pick --no-commit`, which git does not refuse the way it refuses a
	// plain pick, so the refusal has to be safegit's own.
	if code := refuseComputeOverInFlight(flags, gitDir, "cherry-pick"); code != 0 {
		return code
	}

	if flags.dryRun {
		// No git cherry-pick runs: the invocation is recorded, and the outcome
		// it would have is COMPUTED with git's own merge engine instead of
		// guessed.
		//
		// The RECORDED argv is the compute step's, which is what the execute
		// path runs: a would-do log saying `git cherry-pick <sha>` would
		// describe a mutation -- git authoring the commit -- that nothing here
		// performs.
		recorded := append([]string{"cherry-pick", "--no-commit"}, args...)
		return previewSequencerOperation(flags, "cherry-pick", args, recorded)
	}

	ctx := flags.ctx()
	pos := readOplogPosition(flags)
	picked := parsed.Revisions[0]

	// The commit being applied, resolved BEFORE the compute step because the
	// park file has to name it.
	//
	// An unresolvable revision is deliberately left to git: `safegit cherry-pick
	// no-such-commit` must exit with git's own verdict on that argument, not
	// with a message safegit invented, so the failure is carried rather than
	// reported and the compute step below produces git's error.
	sourceSHA, resolveErr := git.RevParse(ctx, picked+"^{commit}")

	// The compute step. --no-commit is what makes the two halves separable: git
	// works out the pick and stages it, and stops before the commit that would
	// otherwise be git's.
	code = runGitMutation(flags, gitexec.NoDoor, append([]string{"cherry-pick", "--no-commit"}, args...)...)
	if code != 0 {
		// Two very different situations arrive here, and only one of them
		// parked anything: a CONFLICT, which is the ordinary way a pick stops
		// and which `safegit cherry-pick-continue` concludes, and a git refusal
		// that staged nothing at all (an unreadable revision, a repository git
		// would not touch). Unmerged entries in the index are what tells them
		// apart, and writing the park file over the second would leave a
		// repository mid-pick with nothing to conclude.
		if !pickLeftAConflict(ctx) {
			return code
		}
		if err := parkComputedPick(gitDir, sourceSHA, resolveErr); err != nil {
			errorf(flags, "%v", err)
			return exitcode.General
		}
		appendOperationEntry(flags, sgDir, "cherry-pick", pos, false, pickExtra(picked))
		announceWayOut(flags, gitDir)
		return code
	}

	if err := parkComputedPick(gitDir, sourceSHA, resolveErr); err != nil {
		errorf(flags, "%v", err)
		return exitcode.General
	}

	state, err := sequencer.Read(gitDir)
	if err != nil {
		errorf(flags, "reading the cherry-pick state: %v", err)
		return exitcode.General
	}
	if state.Kind != sequencer.KindCherryPick {
		// git's operation state CHANGED while the compute ran. Nothing was in
		// flight when this command started -- the entry check looked, inside the
		// operation lock -- and safegit wrote CHERRY_PICK_HEAD itself a moment
		// ago, so a state that is not a cherry-pick now is one somebody else
		// started or cleared underneath. The operation lock serializes safegit
		// processes in this worktree and nothing else: raw git run beside safegit
		// is exactly the situation this tool exists for.
		//
		// Everything is REPORTED and nothing is rolled back, which is the same
		// stance the revert sibling takes: discarding the staged result means
		// throwing the index and the working tree back to HEAD in the one
		// situation where another process is demonstrably operating here, and that
		// rollback could take its work with it. safegit refuses to ship work it
		// cannot account for; it does not destroy it.
		//
		// What it owes instead is an INVENTORY, because the leftovers are not all
		// git's: the park file is safegit's own write (`git cherry-pick
		// --no-commit` records nothing about the commit it applies), so an
		// operator finding it would otherwise have no account of where it came
		// from.
		errorf(flags, "git's operation state changed while the cherry-pick was being computed (%s now); nothing was committed\n"+
			"  nothing was in flight when this command started, so something else started or cleared a\n"+
			"  git operation in this worktree while it ran.%s\n"+
			"  All of it is left exactly where it is, because something else is operating here and a\n"+
			"  rollback could take that work with it. Inspect it with 'git status', then commit it or\n"+
			"  drop it yourself.", state.String(), computedPickLeftovers(ctx, gitDir))
		return exitcode.General
	}

	// Clean, and nothing asked for it to be left in flight: conclude it now,
	// through the same engine `safegit cherry-pick-continue` runs. The message
	// is git's own MERGE_MSG draft, which already carries whatever the compute
	// step put there (an `-x` reference line, a signoff trailer), so nothing is
	// re-derived here.
	out, exit, ok := concludeParkedOperation(flags, gitDir, sgDir, state, parkedConclusion{
		op:           cherryPickContinueOp,
		oplogOp:      "cherry-pick",
		parentBumpOp: "cherry-pick",
		onEmpty:      refuseEmptyCherryPick,
	})
	if !ok {
		return exit
	}

	flags.payload(cherryPickPayload{
		Operation:      "cherry-pick",
		Source:         state.Source,
		Ref:            out.commit.Ref,
		SHA:            realSHA(flags, out.commit.SHA),
		Parents:        orEmpty(out.commit.Parents),
		Tree:           out.commit.Tree,
		Files:          orEmpty(out.commit.Files),
		Author:         reportedAuthor(out.author),
		StateCleared:   out.cleared,
		Attempts:       out.commit.Attempts,
		DeclinedChecks: orEmptyDeclines(out.declines),
		Residue:        orEmptyResidue(out.residue),
		DryRun:         flags.dryRun,
	})
	cherryPickContinueOp.renderHuman(flags, out, "picked "+short(picked, state.Source))
	return exit
}

// parkComputedPick writes the park file for a pick git has just computed.
//
// The resolution error is carried in rather than checked at the call site
// because the two are one decision: the file must name the commit being
// applied, so a pick git applied whose revision safegit could not read is a
// state safegit cannot park -- and saying so is better than writing a file that
// names nothing.
func parkComputedPick(gitDir, sourceSHA string, resolveErr error) error {
	if resolveErr != nil {
		return fmt.Errorf("git applied the cherry-pick, but the commit it applied could not be resolved: %w", resolveErr)
	}
	if err := sequencer.MarkCherryPick(gitDir, sourceSHA); err != nil {
		return fmt.Errorf("recording which commit the cherry-pick is applying: %w", err)
	}
	return nil
}

// computedPickLeftovers names what a cherry-pick whose state changed under it
// has left in the repository, as lines for the refusal, each beginning with a
// newline: the pick's own state files that are actually there, and the paths
// its compute step staged.
//
// The state-file set is read from sequencer.Paths -- the one declaration of what
// a cherry-pick's state IS -- rather than spelled again here, and filtered to
// what exists, because naming a file that is not there would send an operator
// looking for it. CHERRY_PICK_HEAD is called out by name in the line above the
// list: it is the one member of that set safegit wrote itself, and an operator
// who knows `git cherry-pick --no-commit` writes no such file would otherwise
// have no account of it.
//
// Each half degrades on its own. A listing that cannot be read says so and the
// rest of the message still prints: this is already the failure path, and a
// second failure inside the report must not replace the report.
func computedPickLeftovers(ctx context.Context, gitDir string) string {
	var b strings.Builder
	var present []string
	for _, name := range sequencer.Paths(sequencer.KindCherryPick) {
		if _, err := os.Lstat(filepath.Join(gitDir, name)); err == nil {
			present = append(present, name)
		}
	}
	if len(present) > 0 {
		b.WriteString("\n  Left behind, CHERRY_PICK_HEAD included -- safegit wrote that one itself, so the parked" +
			"\n  pick would look to git exactly like a conflicted one:")
		for _, name := range present {
			fmt.Fprintf(&b, "\n    %s", filepath.Join(gitDir, name))
		}
	}

	staged, err := git.IndexPathsChangedFrom(ctx, "HEAD")
	if err != nil {
		fmt.Fprintf(&b, "\n  The computed pick is still staged in the index; what it touched could not be listed: %v", err)
		return b.String()
	}
	if len(staged) == 0 {
		b.WriteString("\n  The index holds nothing the branch does not already have.")
		return b.String()
	}
	sort.Strings(staged)
	b.WriteString("\n  Staged in the index and the working tree, uncommitted:")
	for _, path := range staged {
		fmt.Fprintf(&b, "\n    %s", path)
	}
	return b.String()
}

// pickLeftAConflict reports whether the compute step stopped on a conflict, as
// opposed to failing before it applied anything. The index is the only witness:
// git's exit code is 1 for both a conflict and several refusals.
func pickLeftAConflict(ctx context.Context) bool {
	sides, err := conflict.Stages(ctx, "")
	return err == nil && len(sides) > 0
}

// pickExtra is the per-pick half of an oplog entry: which commit was named. The
// outcome field is appendOperationEntry's own.
func pickExtra(picked string) map[string]interface{} {
	return map[string]interface{}{"commit": picked}
}

// refuseEmptyCherryPick covers a pick whose change the branch already carries.
// git refuses the same case, and safegit's own compute step has already been
// unparked by the time this is called -- so the message says which of the two
// states the operator is left in, and offers an abort only where there is still
// something to abort.
//
// The residue detail follows the headline and the advice comes last, so the line an operator
// acts on is the one nearest their cursor.
func refuseEmptyCherryPick(flags globalFlags, cleanup cleanEmptyParkOutcome) int {
	msg := "this cherry-pick produces no change: the branch already carries the commit's effect" + cleanup.residueLines()
	if cleanup.cleaned() {
		errorf(flags, "%s\n"+
			"  nothing was committed, and the cherry-pick state safegit parked has been cleaned up:\n"+
			"  the branch, the index and the working tree stand where they did, and the next\n"+
			"  safegit command just works.", msg)
		return exitcode.General
	}
	errorf(flags, "%s\n"+
		"  nothing was committed, but the pick is STILL in progress; drop it with:\n"+
		"    git cherry-pick --abort", msg)
	return exitcode.General
}

// reportedAuthor renders the identity a payload states, empty where the
// operation recorded none.
func reportedAuthor(info *git.AuthorInfo) continueAuthor {
	if info == nil {
		return continueAuthor{}
	}
	return continueAuthor{Name: info.Name, Email: info.Email}
}

// cherryPickPayload is what `safegit cherry-pick` puts in the envelope's
// payload.
//
// It follows the conclusion payload -- the members cherry-pick-continue reports
// -- minus the resolution members, which a pick safegit itself started never
// has: it concludes a clean result, and a conflicted one is not concluded here
// at all. What it adds is `source`: the commit that was picked is the one fact
// about this operation the other members cannot express, because a pick's
// parents name the branch it went onto and not the change it brought.
type cherryPickPayload struct {
	Operation string `json:"operation"`
	// Source is the commit that was picked, as it was resolved rather than as
	// it was typed.
	Source string `json:"source"`
	Ref    string `json:"ref"`
	// SHA is the commit that was created, and null under --dry-run.
	SHA     *string  `json:"sha"`
	Parents []string `json:"parents"`
	Tree    string   `json:"tree"`
	Files   []string `json:"files"`
	// Author is the identity the commit RECORDS, preserved from the picked
	// commit; the committer is whoever ran the command.
	Author         continueAuthor  `json:"author"`
	StateCleared   bool            `json:"state_cleared"`
	Attempts       int             `json:"attempts"`
	DeclinedChecks []declinedCheck `json:"declined_checks"`
	// Residue is every step this cherry-pick owed AFTER its commit and did not finish,
	// never nil. An empty list is a run that finished everything it owed;
	// anything in it is what the commit-stands exit code is about, and without
	// it an envelope carrying that code says only state_cleared:false.
	//
	// There is no autostash member beside it, unlike the conclusion commands'
	// payload: an autostash is a merge's, and this command's coordination check
	// refuses a dirty working tree before git runs at all, so no state safegit
	// starts here can carry one.
	Residue []residueEntry `json:"residue"`
	DryRun  bool           `json:"dry_run"`
}

// cherryPickPayloadSchema is cherry-pick's machine payload contract.
var cherryPickPayloadSchema = strictcli.SchemaObject(
	map[string]interface{}{
		"operation": strictcli.SchemaType("string"),
		"source":    strictcli.SchemaType("string"),
		"ref":       strictcli.SchemaType("string"),
		"sha":       strictcli.SchemaType("string", "null"),
		"parents":   strictcli.SchemaArray(strictcli.SchemaType("string")),
		"tree":      strictcli.SchemaType("string"),
		"files":     strictcli.SchemaArray(strictcli.SchemaType("string")),
		"author": strictcli.SchemaObject(
			map[string]interface{}{
				"name":  strictcli.SchemaType("string"),
				"email": strictcli.SchemaType("string"),
			},
			[]string{"name", "email"},
			false,
		),
		"declined_checks": strictcli.SchemaArray(strictcli.SchemaObject(
			map[string]interface{}{
				"check":  strictcli.SchemaType("string"),
				"path":   strictcli.SchemaType("string"),
				"reason": strictcli.SchemaType("string"),
			},
			[]string{"check", "path", "reason"},
			false,
		)),
		"state_cleared": strictcli.SchemaType("boolean"),
		"attempts":      strictcli.SchemaType("integer"),
		"residue": strictcli.SchemaArray(strictcli.SchemaObject(
			map[string]interface{}{
				"step":   strictcli.SchemaType("string"),
				"detail": strictcli.SchemaType("string"),
			},
			[]string{"step", "detail"},
			false,
		)),
		"dry_run": strictcli.SchemaType("boolean"),
	},
	[]string{"operation", "source", "ref", "sha", "parents", "tree", "files", "author", "state_cleared", "attempts", "declined_checks", "residue", "dry_run"},
	false,
)

// cherryPickHelp is the command's registered help text.
const cherryPickHelp = "apply ONE commit onto the current branch, and author the result: git computes the pick with --no-commit and safegit commits the staged result through its own pipeline -- so a pick safegit performed carries safegit's trailers, ran the repository's commit-msg hook and is reversible with 'safegit undo'. The AUTHOR is preserved from the commit being applied and the committer is you, which is git's own division. A pick git stops on a conflict parks -- safegit writes CHERRY_PICK_HEAD itself, because 'git cherry-pick --no-commit' does not -- and 'safegit cherry-pick-continue' concludes it; 'safegit cherry-pick --continue' is refused and names that command. The command line is a deliberate subset of git's: exactly one commit named as a commit (a range or any other revision set is refused, because a range hands the operation to git's sequencer even when it holds one commit), no --edit, no --ff, no --commit, no --cleanup, no signing and no empty-commit flags. --abort and --quit stay plain passthroughs, because they author nothing and are the way out of a state safegit must not refuse over; --no-commit is forwarded to git too, but it COMPUTES, so it takes the same refusal the restructured form does over an operation git already has in flight"
