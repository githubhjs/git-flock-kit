package main

import (
	"bytes"
	"context"
	crypto_rand "crypto/rand"
	"fmt"
	"path"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/stricttools/safegit/internal/exitcode"
	"github.com/stricttools/safegit/internal/git"
	"github.com/stricttools/safegit/internal/repo"
	"github.com/stricttools/safegit/internal/scan"
	"github.com/stricttools/safegit/internal/submodule"
	"github.com/stricttools/safegit/internal/trailer"
	"github.com/stricttools/strictcli/go/strictcli"
)

// ScrubMatchResult is what `scrub match` reports -- in both modes and in both
// renderings. There is no separate dry-run struct: the preview's scan figures
// and the execution's rewrite figures are members of one result, each present
// exactly when it was measured.
//
// objects_matched exists because the human preview's "in N objects" was never
// objects_scanned: it counts the DISTINCT objects that matched, and the two
// numbers used to live in disjoint branches under names close enough to read as
// the same thing. Both are here now, named for what they count.
type ScrubMatchResult struct {
	Version int    `json:"version"`
	DryRun  bool   `json:"dry_run"`
	Pattern string `json:"pattern"`

	// Preview-only: the scan behind the preview.
	Scope            string `json:"scope,omitempty"`
	ScopeFilter      string `json:"scope_filter,omitempty"`
	ObjectsScanned   *int   `json:"objects_scanned,omitempty"`
	ObjectsMatched   *int   `json:"objects_matched,omitempty"`
	BinarySkipped    *int   `json:"binary_skipped,omitempty"`
	TotalMatches     *int   `json:"total_matches,omitempty"`
	BlobMatches      *int   `json:"blob_matches,omitempty"`
	CommitMatches    *int   `json:"commit_matches,omitempty"`
	TagMatches       *int   `json:"tag_matches,omitempty"`
	FileMatches      *int   `json:"file_matches,omitempty"`
	EstimatedCommits *int   `json:"estimated_commits,omitempty"`

	// Execute-only: what the rewrite did.
	Rewrites          map[string]string `json:"rewrites,omitempty"`
	Tags              []TagRewrite      `json:"tags,omitempty"`
	CommitsRewritten  *int              `json:"commits_rewritten,omitempty"`
	BlobsReplaced     *int              `json:"blobs_replaced,omitempty"`
	MessagesModified  *int              `json:"messages_modified,omitempty"`
	TagsRewritten     *int              `json:"tags_rewritten,omitempty"`
	OldHead           string            `json:"old_head,omitempty"`
	NewHead           string            `json:"new_head,omitempty"`
	PreRewriteRemotes map[string]string `json:"pre_rewrite_remotes,omitempty"`
	// SubmodulePreRewriteRemotes is the same state for the SUBMODULES a run
	// rewrote, nested one entry per submodule path.
	//
	// The nesting is not decoration. Two submodules of one parent routinely
	// carry the same refnames -- `refs/remotes/origin/main` is what `git
	// submodule add` leaves in every one of them -- so a single refname-keyed
	// object can hold only one of them and silently drops the rest. The
	// submodule path is the only key that tells them apart, and it is also the
	// only key that says which repository a recorded SHA belongs to.
	//
	// It is a separate member from PreRewriteRemotes rather than a nested form
	// of it, so that one key never has two shapes: pre_rewrite_remotes is
	// always THIS repository's remote-tracking state, and this is always the
	// submodules'.
	SubmodulePreRewriteRemotes map[string]map[string]string `json:"submodule_pre_rewrite_remotes,omitempty"`
	CleanupOK                  *bool                        `json:"cleanup_ok,omitempty"`
	CleanupErrors              []string                     `json:"cleanup_errors,omitempty"`
	// SyncSkipped is true when the working-tree sync was deliberately not
	// performed because work that was not this rewrite's appeared while the
	// refs were moving. The refs still moved; the working tree was left alone.
	SyncSkipped bool `json:"sync_skipped,omitempty"`
}

// scrubMatchPayloadSchema declares what `scrub match` puts in the envelope's
// payload.
var scrubMatchPayloadSchema = strictcli.SchemaObject(
	map[string]interface{}{
		"version":             strictcli.SchemaType("integer"),
		"dry_run":             strictcli.SchemaType("boolean"),
		"pattern":             strictcli.SchemaType("string"),
		"scope":               strictcli.SchemaEnum("range", "entire_history"),
		"scope_filter":        strictcli.SchemaType("string"),
		"objects_scanned":     strictcli.SchemaType("integer"),
		"objects_matched":     strictcli.SchemaType("integer"),
		"binary_skipped":      strictcli.SchemaType("integer"),
		"total_matches":       strictcli.SchemaType("integer"),
		"blob_matches":        strictcli.SchemaType("integer"),
		"commit_matches":      strictcli.SchemaType("integer"),
		"tag_matches":         strictcli.SchemaType("integer"),
		"file_matches":        strictcli.SchemaType("integer"),
		"estimated_commits":   strictcli.SchemaType("integer"),
		"rewrites":            scrubRewritesSchema,
		"tags":                scrubTagsSchema,
		"commits_rewritten":   strictcli.SchemaType("integer"),
		"blobs_replaced":      strictcli.SchemaType("integer"),
		"messages_modified":   strictcli.SchemaType("integer"),
		"tags_rewritten":      strictcli.SchemaType("integer"),
		"old_head":            strictcli.SchemaType("string"),
		"new_head":            strictcli.SchemaType("string"),
		"pre_rewrite_remotes": scrubRewritesSchema,
		// Dynamic keys at both levels: submodule path, then refname.
		"submodule_pre_rewrite_remotes": strictcli.SchemaObject(nil, nil, scrubRewritesSchema),
		"cleanup_ok":                    strictcli.SchemaType("boolean"),
		"cleanup_errors":                strictcli.SchemaArray(strictcli.SchemaType("string")),
		"sync_skipped":                  strictcli.SchemaType("boolean"),
	},
	[]string{"version", "dry_run", "pattern"},
	false,
)

func runScrubMatch(flags globalFlags, kwargs map[string]interface{}) int {
	const cmd = "scrub match"

	// Flag extraction
	pattern := kwargs["pattern"].(string)
	// The substitution selector elects exactly one member, and the elected
	// record is the only thing the handler reads. Mangle mode can no longer be
	// inferred from "--replace is absent" -- inferring it is how `--no-mangle`
	// alone used to mangle the whole history -- and a state where neither was
	// elected is unrepresentable rather than refused by hand.
	substitution := strictcli.GetElected(kwargs, "substitution")
	mangleMode := substitution.Is(scrubMangleChoice)
	var replace string
	if substitution.Is(scrubReplaceChoice) {
		replace = strictcli.Get[string](substitution.Fields, "value")
	}
	reason := kwargs["reason"].(string)

	var scope *string
	if v := kwargs["scope"]; v != nil {
		s := v.(string)
		scope = &s
		// Validate the glob pattern at parse time.
		if _, err := path.Match(s, ""); err != nil {
			strictcli.ExitNow(exitcode.Usage, fmt.Sprintf("invalid --scope glob: %v", err))
		}
	}

	from, entireHistory := scrubRange(kwargs)

	remapGlobs := kwargsStrSlice(kwargs["remap_shas_in"])
	validateRemapGlobs(remapGlobs)

	// Validation
	gitDir := mustGitDir()
	if err := ensureInitialized(flags, gitDir); err != nil {
		strictcli.ExitNow(exitcode.NotInitialized, exitMessage(err))
	}

	ctx := flags.ctx()

	// The clean-tree requirement belongs to the execute path only; it is checked
	// after the dry-run branch below. A preview is exactly what a dirty working
	// tree is for.

	// Resolve --from if provided
	var fromSHA string
	if from != nil {
		var err error
		fromSHA, err = git.RevParse(ctx, *from)
		if err != nil {
			strictcli.ExitNow(exitcode.General, fmt.Sprintf("resolving --from %q: %v", *from, err))
		}
		isAnc, err := git.IsAncestorOf(ctx, fromSHA, "HEAD")
		if err != nil {
			strictcli.ExitNow(exitcode.General, fmt.Sprintf("checking ancestry of --from: %v", err))
		}
		if !isAnc {
			strictcli.ExitNow(exitcode.General, fmt.Sprintf("--from commit %s is not an ancestor of HEAD", *from))
		}
	}

	// The range is not checked here: --from and --entire-history are a mutex
	// group, and the parser refuses an invocation that elects neither (typing
	// only --no-entire-history declines an option rather than choosing one).

	// Compile regex
	compiledPattern, err := regexp.Compile(pattern)
	if err != nil {
		strictcli.ExitNow(exitcode.Usage, fmt.Sprintf("invalid regex pattern: %v", err))
	}

	// Dry-run mode: purely read-only, no lock needed.
	if flags.dryRun {
		return scrubMatchDryRun(ctx, flags, cmd, compiledPattern, scope, gitDir, pattern, fromSHA, entireHistory)
	}

	// Execute path only: a rewrite of a dirty tree would lose the uncommitted work.
	requireCleanTree(ctx)

	sgDir := repo.SafegitDir(gitDir)

	// Acquire rewrite lock to prevent concurrent scrub operations
	lk := acquireRewriteLock(ctx, flags, gitDir, sgDir, "scrub-match")
	defer lk.Release()

	// Execution mode
	return scrubMatchExecute(ctx, flags, cmd, compiledPattern, replace, mangleMode, reason, fromSHA, entireHistory, scope, remapGlobs, gitDir, sgDir)
}

// scrubMatchDryRun scans all objects and non-object files, prints categorized
// output, and returns 0. When scope is non-nil, only blob matches whose path
// matches the glob are shown.
func scrubMatchDryRun(ctx context.Context, flags globalFlags, cmd string, compiledPattern *regexp.Regexp, scope *string, gitDir string, pattern string, fromSHA string, entireHistory bool) int {
	infof(flags, "Scanning all objects...")
	scanOpts := scan.ScanOpts{FromSHA: fromSHA, EntireHistory: entireHistory}
	results, err := scan.ScanObjects(ctx, compiledPattern, scanOpts)
	if err != nil {
		strictcli.ExitNow(exitcode.General, fmt.Sprintf("scanning objects: %v", err))
	}

	if err := scan.AddAttribution(ctx, results, scanOpts); err != nil {
		strictcli.ExitNow(exitcode.General, fmt.Sprintf("adding attribution: %v", err))
	}

	nonObjectMatches, err := scan.ScanNonObjects(ctx, compiledPattern, gitDir)
	if err != nil {
		strictcli.ExitNow(exitcode.General, fmt.Sprintf("scanning non-object files: %v", err))
	}

	// Scan submodules for matches.
	type subScanResult struct {
		sub     submodule.SubmoduleInfo
		results *scan.ScanResults
		// Categorized once, with the scope filter already applied to blobs, and
		// read twice: by the rewritable-match count and by the printing below.
		blobs   []scan.Match
		commits []scan.Match
		tags    []scan.Match
	}
	var subResults []subScanResult

	// A failure here is fatal. It used to warn and continue with parent-only
	// results, which narrows the SCOPE of the preview: the submodules are part
	// of what the rewrite covers, and a preview that silently leaves them out is
	// the document the operator consents from. A warning does not cure that.
	subs, err := submodule.Enumerate(ctx, gitDir)
	if err != nil {
		strictcli.ExitNow(exitcode.General, fmt.Sprintf("enumerating submodules: %v\n"+
			"A preview cannot state what a scrub would rewrite without this.", err))
	}
	for _, sub := range subs {
		if !sub.Initialized {
			continue
		}
		subOpts := scan.ScanOpts{GitDir: sub.GitDir, WorkTree: sub.WorkTreePath, SubmodulePath: sub.RelativePath, EntireHistory: true}
		subScan, err := scan.ScanObjects(ctx, compiledPattern, subOpts)
		if err != nil {
			warnf(flags, "scanning submodule %s: %v", sub.RelativePath, err)
			continue
		}
		if err := scan.AddAttribution(ctx, subScan, subOpts); err != nil {
			warnf(flags, "adding attribution for submodule %s: %v", sub.RelativePath, err)
		}
		if len(subScan.Matches) > 0 {
			sr := subScanResult{sub: sub, results: subScan}
			for _, m := range subScan.Matches {
				switch m.ObjectType {
				case "blob":
					// Scope patterns are written against parent-repo paths:
					// strip the submodule prefix before matching.
					if scope != nil {
						subScope := scopeForSubmodule(*scope, sub.RelativePath)
						if subScope == "" || !matchScope(subScope, m.Path) {
							continue
						}
					}
					sr.blobs = append(sr.blobs, m)
				case "commit":
					sr.commits = append(sr.commits, m)
				case "tag":
					sr.tags = append(sr.tags, m)
				}
			}
			subResults = append(subResults, sr)
		}
	}

	// Categorize parent matches, applying scope filter to blobs.
	var blobMatches, commitMatches, tagMatches []scan.Match
	for _, m := range results.Matches {
		switch m.ObjectType {
		case "blob":
			if scope != nil && !matchScope(*scope, m.Path) {
				continue
			}
			blobMatches = append(blobMatches, m)
		case "commit":
			commitMatches = append(commitMatches, m)
		case "tag":
			tagMatches = append(tagMatches, m)
		}
	}

	totalMatches := len(results.Matches) + len(nonObjectMatches)
	for _, sr := range subResults {
		totalMatches += len(sr.results.Matches)
	}

	// Count unique objects
	uniqueObjects := make(map[string]bool)
	for _, m := range results.Matches {
		uniqueObjects[m.SHA] = true
	}
	for _, sr := range subResults {
		for _, m := range sr.results.Matches {
			uniqueObjects[m.SHA] = true
		}
	}

	// The one computation both renderings read. objectsMatched is the "in N
	// objects" denominator the line below prints, and it is a payload member of
	// its own -- it is NOT objects_scanned, which counts what the scan walked.
	objectsMatched := len(uniqueObjects) + len(nonObjectMatches)
	scopeStr := "entire_history"
	if fromSHA != "" {
		scopeStr = "range"
	}
	scopeFilter := ""
	if scope != nil {
		scopeFilter = *scope
	}
	result := ScrubMatchResult{
		Version:          1,
		DryRun:           true,
		Pattern:          pattern,
		Scope:            scopeStr,
		ScopeFilter:      scopeFilter,
		ObjectsScanned:   intPtr(results.Scanned),
		ObjectsMatched:   intPtr(objectsMatched),
		BinarySkipped:    intPtr(results.Skipped),
		TotalMatches:     intPtr(totalMatches),
		BlobMatches:      intPtr(len(blobMatches)),
		CommitMatches:    intPtr(len(commitMatches)),
		TagMatches:       intPtr(len(tagMatches)),
		FileMatches:      intPtr(len(nonObjectMatches)),
		EstimatedCommits: intPtr(estimateCommitCount(ctx, fromSHA, entireHistory)),
	}

	// Only object-store matches are rewritable, and only the ones the scope
	// filter keeps. The execute path returns before a single ref moves in both
	// of those cases -- it says "0 commits contained the pattern" when the scan
	// finds nothing, and the same with "within scope" when --scope leaves
	// nothing -- so a preview that minted the rewrite here
	// promised four mutations (update-ref, reflog expire, repack, prune) that a
	// real run would never make. This is the guard scrubRunDryRun already has.
	// Non-object matches (working tree files, .git/config, hooks) are reported
	// because they were found, but no history rewrite touches them.
	rewritable := len(blobMatches) + len(commitMatches) + len(tagMatches)
	for _, sr := range subResults {
		rewritable += len(sr.blobs) + len(sr.commits) + len(sr.tags)
	}
	if rewritable == 0 {
		flags.payload(result)
		if len(nonObjectMatches) > 0 {
			infof(flags, "Found %d matches in non-object files:", len(nonObjectMatches))
			for _, m := range nonObjectMatches {
				infof(flags, "  %s (line %d): %s", m.Path, m.Line, m.Context)
			}
			infof(flags, "")
		}
		if scope != nil && len(results.Matches) > 0 {
			infof(flags, "No matches found within scope. Nothing to rewrite.")
		} else {
			infof(flags, "No matches found. Nothing to rewrite.")
		}
		return 0
	}

	infof(flags, "Found %d matches in %d objects:", *result.TotalMatches, *result.ObjectsMatched)

	// Print parent repo header only if submodules have matches too.
	hasSubMatches := len(subResults) > 0
	if hasSubMatches {
		infof(flags, "\nParent repo:")
	}

	if len(blobMatches) > 0 {
		infof(flags, "\nBlobs:")
		for _, m := range blobMatches {
			if m.Path != "" && m.CommitSHA != "" {
				infof(flags, "  %s in commit %s (line %d): %s", m.Path, shortSHA(m.CommitSHA), m.Line, m.Context)
			} else if m.Path != "" {
				infof(flags, "  %s (unreachable, line %d): %s", m.Path, m.Line, m.Context)
			} else if m.Reachable {
				infof(flags, "  blob %s (line %d): %s", shortSHA(m.SHA), m.Line, m.Context)
			} else {
				infof(flags, "  blob %s (unreachable, line %d): %s", shortSHA(m.SHA), m.Line, m.Context)
			}
		}
	}

	if len(commitMatches) > 0 {
		infof(flags, "\nCommit messages:")
		for _, m := range commitMatches {
			infof(flags, "  commit %s (line %d): %s", shortSHA(m.SHA), m.Line, m.Context)
		}
	}

	if len(tagMatches) > 0 {
		infof(flags, "\nTag annotations:")
		for _, m := range tagMatches {
			infof(flags, "  tag %s (line %d): %s", shortSHA(m.SHA), m.Line, m.Context)
		}
	}

	if len(nonObjectMatches) > 0 {
		infof(flags, "\nNon-object files:")
		for _, m := range nonObjectMatches {
			infof(flags, "  %s (line %d): %s", m.Path, m.Line, m.Context)
		}
	}

	// Print submodule results grouped by submodule.
	for _, sr := range subResults {
		infof(flags, "\n[%s]:", sr.sub.RelativePath)
		subBlobs, subCommits, subTags := sr.blobs, sr.commits, sr.tags
		if len(subBlobs) > 0 {
			infof(flags, "  Blobs:")
			for _, m := range subBlobs {
				if m.Path != "" && m.CommitSHA != "" {
					infof(flags, "    %s in commit %s (line %d): %s", m.Path, shortSHA(m.CommitSHA), m.Line, m.Context)
				} else if m.Path != "" {
					infof(flags, "    %s (unreachable, line %d): %s", m.Path, m.Line, m.Context)
				} else {
					infof(flags, "    blob %s (line %d): %s", shortSHA(m.SHA), m.Line, m.Context)
				}
			}
		}
		if len(subCommits) > 0 {
			infof(flags, "  Commit messages:")
			for _, m := range subCommits {
				infof(flags, "    commit %s (line %d): %s", shortSHA(m.SHA), m.Line, m.Context)
			}
		}
		if len(subTags) > 0 {
			infof(flags, "  Tag annotations:")
			for _, m := range subTags {
				infof(flags, "    tag %s (line %d): %s", shortSHA(m.SHA), m.Line, m.Context)
			}
		}
	}

	// The rewrite this preview describes, minted so the framework renders it:
	// the would-do log in human mode, the envelope's preview member in machine
	// mode. A preview that recorded nothing read as "this would change nothing".
	oldHeadSHA, _ := git.RevParse(ctx, "HEAD")
	recordHistoryRewrite(ctx, flags, oldHeadSHA)
	flags.payload(result)

	infof(flags, "\nSummary: %d blob matches, %d message matches, %d tag matches, %d file matches",
		*result.BlobMatches, *result.CommitMatches, *result.TagMatches, *result.FileMatches)
	if *result.BinarySkipped > 0 {
		infof(flags, "Binary blobs skipped: %d", *result.BinarySkipped)
	}
	infof(flags, "Estimated commits in range: %d", *result.EstimatedCommits)

	return 0
}

// scopeForSubmodule checks if a scope pattern applies to a submodule. If the
// scope path starts with the submodule's relative path, the prefix is stripped
// and the remaining path is returned as the scope within the submodule. If the
// scope doesn't match the submodule's prefix, returns empty string (meaning
// this scope doesn't apply to this submodule). A bare glob like "*.env" applies
// to all repos (parent and submodules).
func scopeForSubmodule(scope, subRelPath string) string {
	// Bare globs (no path separator) apply everywhere.
	if !strings.Contains(scope, "/") {
		return scope
	}
	// Check if scope starts with the submodule path prefix.
	prefix := subRelPath + "/"
	if strings.HasPrefix(scope, prefix) {
		return scope[len(prefix):]
	}
	// Also check using filepath separator in case of OS-specific paths.
	fpPrefix := filepath.ToSlash(subRelPath) + "/"
	if strings.HasPrefix(scope, fpPrefix) {
		return scope[len(fpPrefix):]
	}
	return ""
}

// submoduleScrubResult holds the computed rewrite state for a single submodule
// before any refs are updated. All computation is deferred so that ref updates
// can be applied atomically after all submodules + parent succeed.
type submoduleScrubResult struct {
	sub              submodule.SubmoduleInfo
	shaMap           map[string]string
	rewrittenCount   int
	blobMap          map[string]string
	messagesModified int
	// intent is what the submodule walk decided to change, per commit, which
	// the submodule's own Finalize verifies before its refs move.
	intent *RewriteIntent
}

// scrubMatchExecute performs the actual rewrite: handles submodule processing,
// then delegates parent repo rewriting to executeScrubRecipe. When scope is
// non-nil, only blobs that appear at paths matching the glob are included.
func scrubMatchExecute(
	ctx context.Context,
	flags globalFlags,
	cmd string,
	compiledPattern *regexp.Regexp,
	replace string,
	mangleMode bool,
	reason string,
	fromSHA string,
	entireHistory bool,
	scope *string,
	remapGlobs []string,
	gitDir string,
	sgDir string,
) int {
	pattern := compiledPattern.String()

	// Scan to find all matches (always uses EntireHistory to find ALL matching
	// blobs, even those introduced before --from).
	infof(flags, "Scanning objects...")
	parentOpts := scan.ScanOpts{EntireHistory: true}
	results, err := scan.ScanObjects(ctx, compiledPattern, parentOpts)
	if err != nil {
		strictcli.ExitNow(exitcode.General, fmt.Sprintf("scanning objects: %v", err))
	}

	// Enumerate submodules. A failure is fatal for the same reason it is in the
	// preview: the submodules are part of what this rewrite covers, so an empty
	// list is not a smaller rewrite but a rewrite that leaves the matched
	// content where it is while reporting success. Nothing has moved yet.
	subs, subErr := submodule.Enumerate(ctx, gitDir)
	if subErr != nil {
		strictcli.ExitNow(exitcode.General, fmt.Sprintf("enumerating submodules: %v\n"+
			"A scrub cannot decide what it rewrites without this. Nothing was changed.", subErr))
	}
	// Ensure safegit dir exists for each initialized submodule.
	for _, sub := range subs {
		if sub.Initialized {
			if err := ensureInitialized(flags, sub.GitDir); err != nil {
				warnf(flags, "initializing safegit for submodule %s: %v", sub.RelativePath, err)
			}
		}
	}

	if len(results.Matches) == 0 {
		// Check submodules too before declaring no matches.
		anySubMatches := false
		for _, sub := range subs {
			if !sub.Initialized {
				continue
			}
			subCheckOpts := scan.ScanOpts{GitDir: sub.GitDir, WorkTree: sub.WorkTreePath, SubmodulePath: sub.RelativePath, EntireHistory: true}
			subResults, err := scan.ScanObjects(ctx, compiledPattern, subCheckOpts)
			if err != nil {
				continue
			}
			if len(subResults.Matches) > 0 {
				anySubMatches = true
				break
			}
		}
		if !anySubMatches {
			infof(flags, "0 commits contained the pattern. Nothing was rewritten and no history changed.")
			// A search that matched nothing is a successful ANSWER, and machine
			// mode has to be able to read it: the payload states the zeroes
			// rather than leaving the envelope's payload absent.
			flags.payload(nothingRewrittenMatchPayload(ctx, pattern))
			return 0
		}
	}

	// When --scope is set, build a blob SHA -> paths index so we can filter
	// blobs by the paths they appear at.
	var scopedBlobSHAs map[string]bool
	if scope != nil {
		scopedBlobSHAs, err = buildScopedBlobSet(ctx, *scope)
		if err != nil {
			strictcli.ExitNow(exitcode.General, fmt.Sprintf("building scoped blob set: %v", err))
		}
	}

	// Count matches by type for summary
	var blobMatchCount, commitMatchCount, tagMatchCount int
	for _, m := range results.Matches {
		switch m.ObjectType {
		case "blob":
			if scope != nil && !scopedBlobSHAs[m.SHA] {
				continue
			}
			blobMatchCount++
		case "commit":
			commitMatchCount++
		case "tag":
			tagMatchCount++
		}
	}

	// Scan submodules for matches (4.5)
	type subScanInfo struct {
		sub         submodule.SubmoduleInfo
		uniqueBlobs map[string]bool
		blobCount   int
		commitCount int
		tagCount    int
	}
	var subScans []subScanInfo
	for _, sub := range subs {
		if !sub.Initialized {
			continue
		}
		// Determine if this submodule is in scope.
		if scope != nil {
			subScope := scopeForSubmodule(*scope, sub.RelativePath)
			if subScope == "" {
				continue
			}
		}
		subScanOpts := scan.ScanOpts{GitDir: sub.GitDir, WorkTree: sub.WorkTreePath, SubmodulePath: sub.RelativePath, EntireHistory: true}
		subResults, err := scan.ScanObjects(ctx, compiledPattern, subScanOpts)
		if err != nil {
			strictcli.ExitNow(exitcode.General, fmt.Sprintf("scanning submodule %s: %v", sub.RelativePath, err))
		}
		if len(subResults.Matches) == 0 {
			continue
		}

		// Build scoped blob set for submodule if scope applies.
		var subScopedBlobs map[string]bool
		if scope != nil {
			subScope := scopeForSubmodule(*scope, sub.RelativePath)
			if subScope != "" {
				subScopedBlobs, err = buildScopedBlobSetWithDir(ctx, subScope, sub.GitDir, sub.WorkTreePath)
				if err != nil {
					strictcli.ExitNow(exitcode.General, fmt.Sprintf("building scoped blob set for submodule %s: %v", sub.RelativePath, err))
				}
			}
		}

		info := subScanInfo{sub: sub, uniqueBlobs: make(map[string]bool)}
		for _, m := range subResults.Matches {
			switch m.ObjectType {
			case "blob":
				if subScopedBlobs != nil && !subScopedBlobs[m.SHA] {
					continue
				}
				info.blobCount++
				info.uniqueBlobs[m.SHA] = true
			case "commit":
				info.commitCount++
			case "tag":
				info.tagCount++
			}
		}
		if info.blobCount > 0 || info.commitCount > 0 || info.tagCount > 0 {
			subScans = append(subScans, info)
		}
	}

	// If scope filtered out all blob matches and there are no message/tag matches,
	// treat as no matches.
	totalSubBlobCount := 0
	totalSubCommitCount := 0
	totalSubTagCount := 0
	for _, si := range subScans {
		totalSubBlobCount += si.blobCount
		totalSubCommitCount += si.commitCount
		totalSubTagCount += si.tagCount
	}
	if blobMatchCount == 0 && commitMatchCount == 0 && tagMatchCount == 0 &&
		totalSubBlobCount == 0 && totalSubCommitCount == 0 && totalSubTagCount == 0 {
		infof(flags, "0 commits contained the pattern within scope. Nothing was rewritten and no history changed.")
		// A search that matched nothing is a successful ANSWER, and machine mode
		// has to be able to read it: the payload states the zeroes rather than
		// leaving the envelope's payload absent.
		flags.payload(nothingRewrittenMatchPayload(ctx, pattern))
		return 0
	}

	totalBlobs := blobMatchCount + totalSubBlobCount
	totalCommits := commitMatchCount + totalSubCommitCount
	totalTags := tagMatchCount + totalSubTagCount
	infof(flags, "Found %d matches (%d in blobs, %d in commit messages, %d in tag annotations)",
		totalBlobs+totalCommits+totalTags, totalBlobs, totalCommits, totalTags)
	if len(subScans) > 0 {
		infof(flags, "  Submodules with matches: %d", len(subScans))
	}

	// `scrub match` declares itself consequential, so the framework's confirm
	// protocol already took deliberate consent for this rewrite before dispatch.
	// The scale is stated above, not asked a second time.
	infof(flags, "Rewriting history to replace pattern matches. This cannot be undone.")

	// Phase 1: rewrite each submodule's OBJECTS -- blob map and walkAndRewrite.
	// Nothing is published here: the submodules are carried as pending rewrites
	// through the parent's own walk and verified with it (see below).
	//
	// subTierBFailed records a submodule whose own post-rewrite verification
	// found something: the submodule rewrite stands, and the command's exit
	// code says so.
	subTierBFailed := false
	var subScrubResults []submoduleScrubResult
	for _, si := range subScans {
		infof(flags, "Scrubbing submodule [%s]...", si.sub.RelativePath)

		// Context-scoped git directory targeting: all git commands using
		// subCtx will target the submodule's repo without os.Chdir.
		subCtx := git.WithDir(ctx, si.sub.GitDir, si.sub.WorkTreePath)

		// Each submodule is a repository of its own and gets its own rewrite
		// lock, taken INSIDE the parent's (held since this command's entry) --
		// the parent-then-submodule order declared at acquireRewriteLock. The
		// lock is held until this function returns, which is after every
		// repository has been verified and published.
		subLk := acquireRewriteLock(subCtx, flags, si.sub.GitDir, si.sub.SafegitDir, "scrub-match")
		defer subLk.Release()

		// The range this submodule is rewritten over, decided BEFORE a single
		// object is written: an elected --from is mapped through the gitlink the
		// boundary commit records, and a mapping that fails is a hard error
		// rather than a silent widening to the submodule's whole history.
		subFromSHA := ""
		if !entireHistory {
			subFromSHA = submoduleFromBoundary(ctx, subCtx, fromSHA, si.sub)
		}

		// Build blob replacement map for this submodule.
		subBlobMap := make(map[string]string, len(si.uniqueBlobs))
		for blobSHA := range si.uniqueBlobs {
			content, err := git.CatFileBlob(subCtx, blobSHA)
			if err != nil {
				strictcli.ExitNow(exitcode.General, fmt.Sprintf("submodule %s: reading blob %s: %v", si.sub.RelativePath, blobSHA, err))
			}
			if isBinaryContent(content) {
				continue
			}
			var modified []byte
			if mangleMode {
				modified = compiledPattern.ReplaceAllFunc(content, mangleBytes)
			} else {
				modified = compiledPattern.ReplaceAll(content, []byte(replace))
			}
			if bytes.Equal(content, modified) {
				continue
			}
			newSHA, err := git.HashObjectWriteBytes(subCtx, modified)
			if err != nil {
				strictcli.ExitNow(exitcode.General, fmt.Sprintf("submodule %s: writing replaced blob: %v", si.sub.RelativePath, err))
			}
			subBlobMap[blobSHA] = newSHA
			if flags.verbose {
				debugf(flags, "  [%s] blob %s -> %s", si.sub.RelativePath, shortSHA(blobSHA), shortSHA(newSHA))
			}
		}

		// The commits to walk, from the range elected above -- listed by the one
		// helper every scrub range goes through, so a submodule's range and the
		// parent's can never be computed two different ways.
		subSHAs := scrubFileCommitRange(subCtx, subFromSHA, entireHistory)

		// Note: --remap-shas-in is not applied inside submodule histories
		// (documented limitation).
		subMessagesModified := 0
		subTreeCache := make(map[string]treeRewrite)
		subIntent := PerPathIntent()
		subShaMap, subRewrittenCount, err := walkAndRewrite(flags, subCtx, subSHAs, func(ctx context.Context, sha string, info git.CommitInfo, remappedParents []string, shaMap map[string]string) (CommitTransform, error) {
			var xform CommitTransform

			newTreeSHA, changedPaths, err := replaceInTreeByBlobMap(ctx, info.Tree, subBlobMap, nil, subTreeCache)
			if err != nil {
				return CommitTransform{}, fmt.Errorf("replacing blobs in tree for commit %s: %w", sha, err)
			}
			subIntent.Declare(sha, changedPaths, false)
			if newTreeSHA != info.Tree {
				xform.TreeSHA = newTreeSHA
			}

			if compiledPattern.MatchString(info.Message) {
				// The same trailer-aware rewrite the parent walk uses: a match
				// overlapping a move record's quoted path is substituted inside
				// the decoded path and re-encoded, never in the raw line.
				newMessage, err := trailer.RewriteMessage(info.Message, patternSubstitution(compiledPattern, mangleMode, &replace))
				if err != nil {
					// The submodule's own walk refuses on the same terms the
					// parent's does, and it refuses BEFORE any repository in
					// this operation publishes anything.
					return CommitTransform{}, refuseCorruptRecord(sha, err)
				}
				if newMessage != info.Message {
					xform.Message = newMessage
					subMessagesModified++
					subIntent.Declare(sha, nil, true)
				}
			}

			return xform, nil
		}, flags.verbose)
		if err != nil {
			exitFinalize(fmt.Sprintf("submodule %s", si.sub.RelativePath), err)
		}

		subScrubResults = append(subScrubResults, submoduleScrubResult{
			sub:              si.sub,
			shaMap:           subShaMap,
			rewrittenCount:   subRewrittenCount,
			blobMap:          subBlobMap,
			messagesModified: subMessagesModified,
			intent:           subIntent,
		})

		infof(flags, "  [%s] %d commits rewritten, %d blobs replaced",
			si.sub.RelativePath, subRewrittenCount, len(subBlobMap))
	}

	// Every submodule's rewritten commits now exist as unreachable objects, and
	// NONE of them is published. The parent walk below builds its own commits
	// against those SHAs, and the whole set -- every submodule plus the parent --
	// is verified before any repository's refs move, so a parent-side refusal
	// leaves every submodule exactly as it was.
	var subPending []*pendingRewrite
	subResults := make([]*RewriteResult, 0, len(subScrubResults))
	for _, sr := range subScrubResults {
		// Context-scoped git directory for this submodule's ref updates.
		subCtx := git.WithDir(ctx, sr.sub.GitDir, sr.sub.WorkTreePath)

		// Capture old HEAD before refs are updated. The error is fatal like at
		// every sibling site: this SHA is the baseline the submodule's
		// cleanliness check compares against and the old_head its journal
		// record carries, and a rewrite that cannot name where it started from
		// must not run.
		subOldHead, err := git.RevParse(subCtx, "HEAD")
		if err != nil {
			strictcli.ExitNow(exitcode.General, fmt.Sprintf("submodule %s: resolving HEAD: %v", sr.sub.RelativePath, err))
		}

		// Tier A for the submodule: the pattern must be absent from the
		// submodule history that is about to be published.
		subTierA := func(ctx context.Context, plan *RefUpdatePlan) error {
			return verifyPatternAbsentFromTips(ctx, compiledPattern, nil, plan.WalkedTips, nil)
		}

		// Oplog extra for submodule (ref, oldHead, sha, rewritten are
		// added by Finalize).
		//
		// The oplog records METADATA about the scrub and no content: no
		// pattern, no replacement text. See the parent's extra below for why.
		subOplogExtra := map[string]interface{}{
			"reason":           reason,
			"mode":             scrubMatchMode(mangleMode),
			"blobsReplaced":    len(sr.blobMap),
			"messagesModified": sr.messagesModified,
			"parentScrub":      true,
		}

		subResult := &RewriteResult{
			ShaMap:         sr.shaMap,
			RewrittenCount: sr.rewrittenCount,
			Intent:         sr.intent,
			OldHeadSHA:     subOldHead,
			SgDir:          sr.sub.SafegitDir,
			Reason:         reason,
			OpName:         "scrub-match",
			OplogExtra:     subOplogExtra,
		}
		subResults = append(subResults, subResult)
		subPending = append(subPending, &pendingRewrite{
			Label:  fmt.Sprintf("submodule %s", sr.sub.RelativePath),
			Ctx:    subCtx,
			Result: subResult,
			Hooks: RewriteHooks{
				AnnotateTag: patternTagBodyTransform(compiledPattern, replace, mangleMode),
				TierA:       subTierA,
			},
		})
	}

	// Build the combined gitlink map from all submodule SHA mappings.
	var gitlinkMap map[string]string
	if len(subScrubResults) > 0 {
		gitlinkMap = make(map[string]string)
		for _, sr := range subScrubResults {
			for old, new_ := range sr.shaMap {
				if old != new_ {
					gitlinkMap[old] = new_
				}
			}
		}
		if len(gitlinkMap) == 0 {
			gitlinkMap = nil
		}
	}

	// Phase 2: Construct a single-operation ParsedRecipe and delegate parent
	// repo rewriting to executeScrubRecipe.
	var recipeReplace *string
	if !mangleMode {
		recipeReplace = &replace
	}
	recipe := &ParsedRecipe{
		Operations: []RecipeOperation{{
			Pattern: pattern,
			Replace: recipeReplace,
			Mangle:  mangleMode,
			Scope:   scope,
		}},
		Patterns:  []*regexp.Regexp{compiledPattern},
		TopoOrder: []int{0},
	}

	// Build oplog extra with scrub-match specific fields.
	//
	// The oplog keeps METADATA ONLY -- op, reason, scope, mode, counts -- and
	// records no content: neither the pattern nor the replacement text is
	// written. The pattern is the secret itself often enough that persisting it
	// under .git would undo the scrub in the one file the scrub does not touch,
	// and the replacement is both redundant with the rewritten history (it sits
	// at every scrubbed location in the new commits) and sometimes sensitive in
	// its own right, since operators do reach for a rotated value there.
	parentOplogExtra := map[string]interface{}{
		"reason":     reason,
		"mode":       scrubMatchMode(mangleMode),
		"submodules": len(subScrubResults),
	}
	if scope != nil {
		parentOplogExtra["scope"] = *scope
	}

	// Skip confirmation in executeScrubRecipe (already confirmed above).
	execFlags := flags
	execFlags.approved = true // carries the consent already given, not a bypass

	exitCode, result := executeScrubRecipe(ctx, execFlags, cmd, recipe, reason, fromSHA, entireHistory, scope, remapGlobs, gitDir, sgDir, gitlinkMap, "scrub-match", parentOplogExtra, true, subPending)

	// A submodule whose own post-rewrite verification found something is the
	// same verdict as a parent-side finding: the rewrite stands and the exit
	// code says so. A submodule that skipped its working-tree sync is reported
	// the same way -- one command, one outcome, whichever repository left its
	// working tree alone.
	subSyncSkipped := false
	for _, sr := range subResults {
		if sr.SyncSkipped {
			subSyncSkipped = true
		}
		if len(sr.TierBFailures) > 0 {
			subTierBFailed = true
		}
	}

	// Post-execution submodule verification.
	if result != nil && len(subScrubResults) > 0 {
		for _, sr := range subScrubResults {
			subScope := scope
			if scope != nil {
				ss := scopeForSubmodule(*scope, sr.sub.RelativePath)
				if ss != "" {
					subScope = &ss
				} else {
					subScope = nil
				}
			}
			subVerifyOpts := scan.ScanOpts{GitDir: sr.sub.GitDir, WorkTree: sr.sub.WorkTreePath, SubmodulePath: sr.sub.RelativePath, EntireHistory: true}
			// scanResults, not subResults: the enclosing scope already binds
			// subResults to the []*RewriteResult this verification is checking,
			// and shadowing it here with the scan's findings made two unrelated
			// values share one name inside the loop.
			scanResults, scanErr := scan.ScanObjects(ctx, compiledPattern, subVerifyOpts)
			if scanErr != nil {
				errorf(flags, "CRITICAL: re-scan submodule %s failed: %v", sr.sub.RelativePath, scanErr)
				subTierBFailed = true
				continue
			}
			if len(scanResults.Matches) > 0 {
				var remaining []scan.Match
				for _, m := range scanResults.Matches {
					if !m.Reachable {
						continue
					}
					remaining = append(remaining, m)
				}
				if subScope != nil && len(remaining) > 0 {
					if err := scan.AddAttribution(ctx, scanResults, subVerifyOpts); err == nil {
						var filtered []scan.Match
						for _, m := range remaining {
							if m.ObjectType == "blob" && !matchScope(*subScope, m.Path) {
								continue
							}
							filtered = append(filtered, m)
						}
						remaining = filtered
					}
				}
				if len(remaining) > 0 {
					errorf(flags, "CRITICAL: secret still present in submodule %s (%d matches)", sr.sub.RelativePath, len(remaining))
					subTierBFailed = true
				}
			}
		}

		// Verify gitlinks in parent's rewritten history resolve to valid commits.
		if err := verifyGitlinksAfterScrub(ctx, result.ShaMap, subScrubResults); err != nil {
			warnf(flags, "gitlink verification: %v", err)
		}
	}

	// A submodule whose own verification found something turns the exit code
	// the same way the parent's does: the rewrite stands, and the code says
	// what still needs attention.
	if subTierBFailed {
		exitCode = exitcode.RewriteIncomplete
	}

	// No PARENT rewrite was performed: the parent repository held nothing to
	// change while a submodule did, and the submodule's rewrite was verified
	// and published on its own. The command succeeded, so machine mode carries
	// the payload that says what happened -- an envelope with an absent payload
	// is indistinguishable, from the outside, from a command with nothing to
	// report at all.
	if result == nil {
		flags.payload(submoduleOnlyMatchPayload(ctx, pattern, subScrubResults, subResults, subSyncSkipped))
		reportSubmoduleOnlyCompletion(flags, pattern, subScrubResults, subResults)
		return exitCode
	}

	// Combine ref-level tag rewrites with annotation tag rewrites.
	allTagRewrites := append(result.TagRewrites, result.AnnotationTagRewrites...)

	// The one computation both renderings read: the payload's counts are the
	// numbers the summary below prints.
	rewrites := make(map[string]string)
	for old, new_ := range result.ShaMap {
		if old != new_ {
			rewrites[old] = new_
		}
	}
	combinedTagRewrites := make([]TagRewrite, 0, len(allTagRewrites))
	combinedTagRewrites = append(combinedTagRewrites, allTagRewrites...)
	flags.payload(ScrubMatchResult{
		Version:           1,
		DryRun:            false,
		Pattern:           pattern,
		Rewrites:          rewrites,
		Tags:              combinedTagRewrites,
		CommitsRewritten:  intPtr(result.RewrittenCount),
		BlobsReplaced:     intPtr(result.BlobsReplaced),
		MessagesModified:  intPtr(result.MessagesModified),
		TagsRewritten:     intPtr(result.TagsRewrittenCount),
		OldHead:           result.OldHeadSHA,
		NewHead:           result.NewHeadSHA,
		PreRewriteRemotes: nonNilStringMap(result.PreRewriteRemotes),
		CleanupOK:         boolPtr(result.CleanupOK),
		CleanupErrors:     nonNilStrings(result.CleanupErrors),
		SyncSkipped:       result.SyncSkipped || subSyncSkipped,
	})

	// Summary (push hint already printed by Finalize inside executeScrubRecipe)
	infof(flags, "\nScrub complete:")
	infof(flags, "  %d commits rewritten", result.RewrittenCount)
	infof(flags, "  %d blobs replaced", result.BlobsReplaced)
	infof(flags, "  %d commit messages modified", result.MessagesModified)
	infof(flags, "  %d tag annotations rewritten", result.TagsRewrittenCount)
	if len(subScrubResults) > 0 {
		totalSubRewritten := 0
		totalSubBlobs := 0
		for _, sr := range subScrubResults {
			totalSubRewritten += sr.rewrittenCount
			totalSubBlobs += len(sr.blobMap)
		}
		infof(flags, "  %d submodule commits rewritten", totalSubRewritten)
		infof(flags, "  %d submodule blobs replaced", totalSubBlobs)
	}
	infof(flags, "  Old HEAD: %s", result.OldHeadSHA[:12])
	infof(flags, "  New HEAD: %s", result.NewHeadSHA[:12])
	// Every history this match rewrote, not just the parent's: a submodule's
	// history moved too, and an operator reading a scope line that names only
	// the parent has been told the submodule was left alone.
	printScopeNotice(flags, append([]string{result.Ref}, submoduleScopeRefs(subScrubResults, subResults)...)...)
	printRotationNotice(flags, recheckCommandForPatterns(pattern))

	return exitCode
}

// reportSubmoduleOnlyCompletion prints the human completion for the branch
// where the parent repository had nothing to rewrite and one or more submodules
// were rewritten and published.
//
// A successful rewrite completion prints three things -- the summary, the scope
// the rewrite actually had, and the rotation notice -- and this branch printed
// none of them. That silence was a real hazard rather than a cosmetic gap: a
// submodule's history had moved and a credential still needed rotating, while
// the last line an operator saw was "0 commits contained the pattern" about the
// parent. The figures are the submodules' own, because they are the only
// figures this run produced.
func reportSubmoduleOnlyCompletion(flags globalFlags, pattern string, scrubbed []submoduleScrubResult, published []*RewriteResult) {
	if len(scrubbed) == 0 {
		return
	}
	commits, blobs, messages := 0, 0, 0
	for _, sr := range scrubbed {
		commits += sr.rewrittenCount
		blobs += len(sr.blobMap)
		messages += sr.messagesModified
	}
	tags := 0
	for _, r := range published {
		tags += r.TagsRewrittenCount
	}

	infof(flags, "\nScrub complete:")
	infof(flags, "  the parent repository held nothing to rewrite")
	infof(flags, "  %d submodule commits rewritten", commits)
	infof(flags, "  %d submodule blobs replaced", blobs)
	infof(flags, "  %d submodule commit messages modified", messages)
	infof(flags, "  %d submodule tag annotations rewritten", tags)

	printScopeNotice(flags, submoduleScopeRefs(scrubbed, published)...)
	printRotationNotice(flags, recheckCommandForPatterns(pattern))
}

// submoduleScopeRefs names each rewritten submodule history the way the scope
// line spells it: the ref the submodule's rewrite published, and the path the
// submodule sits at.
//
// It is the one spelling for both completions -- the branch where the parent
// was rewritten alongside its submodules, and the branch where only the
// submodules were -- so the two cannot describe the same rewrite differently.
// published is positional against scrubbed; a submodule whose rewrite reported
// no ref is named by its path alone rather than dropped from the scope.
func submoduleScopeRefs(scrubbed []submoduleScrubResult, published []*RewriteResult) []string {
	refs := make([]string, 0, len(scrubbed))
	for i, sr := range scrubbed {
		ref := "its history"
		if i < len(published) && published[i].Ref != "" {
			ref = published[i].Ref
		}
		refs = append(refs, fmt.Sprintf("%s in submodule [%s]", ref, sr.sub.RelativePath))
	}
	return refs
}

// nothingRewrittenMatchPayload is the `scrub match` payload for a search that
// matched nothing anywhere: every count is zero, old_head is where the
// repository still sits, and new_head is ABSENT because nothing was rewritten.
func nothingRewrittenMatchPayload(ctx context.Context, pattern string) ScrubMatchResult {
	oldHead, _ := git.RevParse(ctx, "HEAD")
	return ScrubMatchResult{
		Version:          1,
		DryRun:           false,
		Pattern:          pattern,
		CommitsRewritten: intPtr(0),
		BlobsReplaced:    intPtr(0),
		MessagesModified: intPtr(0),
		TagsRewritten:    intPtr(0),
		OldHead:          oldHead,
	}
}

// submoduleOnlyMatchPayload is the `scrub match` payload for the branch where
// the parent repository had nothing to rewrite and one or more submodules did.
//
// Every figure is the submodules' own, because they are the only figures this
// run produced. old_head is the parent's head, which the run did not move;
// new_head is left ABSENT rather than echoing it, because a new_head equal to
// old_head reads as "the parent was rewritten and arrived where it already was".
func submoduleOnlyMatchPayload(
	ctx context.Context,
	pattern string,
	subScrubResults []submoduleScrubResult,
	subResults []*RewriteResult,
	syncSkipped bool,
) ScrubMatchResult {
	oldHead, _ := git.RevParse(ctx, "HEAD")

	commits, blobs, messages := 0, 0, 0
	for _, sr := range subScrubResults {
		commits += sr.rewrittenCount
		blobs += len(sr.blobMap)
		messages += sr.messagesModified
	}

	tags := []TagRewrite{}
	// Keyed by submodule path, never flat-merged by refname: two submodules of
	// one parent routinely carry the same refnames, so a flat merge keeps
	// whichever one happened to be iterated last and loses the others.
	// subResults is built one entry per subScrubResults entry, in that order,
	// so the two are read together.
	preRewriteRemotes := map[string]map[string]string{}
	tagsRewritten := 0
	cleanupOK := true
	var cleanupErrors []string
	for i, sr := range subResults {
		tags = append(tags, sr.TagRewrites...)
		tags = append(tags, sr.AnnotationTagRewrites...)
		tagsRewritten += sr.TagsRewrittenCount
		if len(sr.PreRewriteRemotes) > 0 && i < len(subScrubResults) {
			path := subScrubResults[i].sub.RelativePath
			remotes := make(map[string]string, len(sr.PreRewriteRemotes))
			for refname, sha := range sr.PreRewriteRemotes {
				remotes[refname] = sha
			}
			preRewriteRemotes[path] = remotes
		}
		if !sr.CleanupOK {
			cleanupOK = false
		}
		cleanupErrors = append(cleanupErrors, sr.CleanupErrors...)
	}

	return ScrubMatchResult{
		Version:          1,
		DryRun:           false,
		Pattern:          pattern,
		Rewrites:         map[string]string{},
		Tags:             tags,
		CommitsRewritten: intPtr(commits),
		BlobsReplaced:    intPtr(blobs),
		MessagesModified: intPtr(messages),
		TagsRewritten:    intPtr(tagsRewritten),
		OldHead:          oldHead,
		// PreRewriteRemotes is deliberately absent: on this branch the PARENT's
		// refs never moved, so it has no pre-rewrite state to record.
		SubmodulePreRewriteRemotes: preRewriteRemotes,
		CleanupOK:                  boolPtr(cleanupOK),
		CleanupErrors:              nonNilStrings(cleanupErrors),
		SyncSkipped:                syncSkipped,
	}
}

// scrubMatchMode names which substitution a `scrub match` elected, for the
// oplog. It is the metadata half of the elected `substitution` selector: which
// KIND of replacement happened, never the text that was written.
func scrubMatchMode(mangleMode bool) string {
	if mangleMode {
		return "mangle"
	}
	return "replace"
}

// verifyGitlinksAfterScrub checks that every gitlink in the parent's rewritten
// history resolves to a valid commit in the corresponding submodule.
func verifyGitlinksAfterScrub(ctx context.Context, parentShaMap map[string]string, subResults []submoduleScrubResult) error {
	// Build a set of all valid new submodule commit SHAs.
	validSubCommits := make(map[string]bool)
	for _, sr := range subResults {
		for _, newSHA := range sr.shaMap {
			validSubCommits[newSHA] = true
		}
	}

	// Check HEAD's tree for gitlinks.
	headSHA, err := git.RevParse(ctx, "HEAD")
	if err != nil {
		return fmt.Errorf("resolving HEAD: %w", err)
	}
	headInfo, err := git.ParseCommit(ctx, headSHA)
	if err != nil {
		return fmt.Errorf("parsing HEAD commit: %w", err)
	}
	entries, err := git.LsTree(ctx, headInfo.Tree)
	if err != nil {
		return fmt.Errorf("ls-tree HEAD: %w", err)
	}

	var failures []string
	for _, e := range entries {
		if e.ObjectType == "commit" {
			// This is a gitlink. Check that it resolves.
			if !validSubCommits[e.SHA] {
				// It might be an unmodified submodule commit (not in the rewrite set).
				// Check that the SHA exists in one of the submodule git dirs.
				found := false
				for _, sr := range subResults {
					if sr.sub.RelativePath == e.Path {
						// Check if this SHA is valid in the submodule.
						_, _, catErr := git.RunWithGitDir(ctx, sr.sub.GitDir, sr.sub.WorkTreePath, "cat-file", "-t", e.SHA)
						if catErr == nil {
							found = true
						}
						break
					}
				}
				if !found {
					failures = append(failures, fmt.Sprintf("gitlink %s at %s does not resolve to a valid commit", shortSHA(e.SHA), e.Path))
				}
			}
		}
	}

	if len(failures) > 0 {
		return fmt.Errorf("%d gitlink(s) invalid:\n  %s", len(failures), strings.Join(failures, "\n  "))
	}
	return nil
}

// buildScopedBlobSetWithDir enumerates all blob-to-path mappings across all
// refs in a specific git directory and returns the set of blob SHAs that appear
// at paths matching the scope glob.
func buildScopedBlobSetWithDir(ctx context.Context, scope, gitDir, workTree string) (map[string]bool, error) {
	stdout, _, err := git.RunWithGitDir(ctx, gitDir, workTree, "rev-list", "--all", "--objects")
	if err != nil {
		return nil, fmt.Errorf("rev-list --all --objects: %w", err)
	}

	result := make(map[string]bool)
	for _, line := range strings.Split(stdout, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		spaceIdx := strings.IndexByte(line, ' ')
		if spaceIdx < 0 {
			continue
		}
		sha := line[:spaceIdx]
		filePath := line[spaceIdx+1:]
		if matchScope(scope, filePath) {
			result[sha] = true
		}
	}
	return result, nil
}

// patternTagBodyTransform builds the annotation transform for `scrub match`:
// the one pattern, substituted or mangled, applied to the tag body.
func patternTagBodyTransform(compiledPattern *regexp.Regexp, replace string, mangleMode bool) TagBodyTransformFunc {
	return func(refname, header, body string) (string, error) {
		if !compiledPattern.MatchString(body) {
			return body, nil
		}
		if mangleMode {
			return compiledPattern.ReplaceAllStringFunc(body, func(s string) string {
				return string(mangleBytes([]byte(s)))
			}), nil
		}
		return compiledPattern.ReplaceAllString(body, replace), nil
	}
}

// shortSHA returns the first 8 characters of a SHA.
func shortSHA(sha string) string {
	if len(sha) > 8 {
		return sha[:8]
	}
	return sha
}

// isBinaryContent checks if content is binary (NUL byte in first 8KB).
func isBinaryContent(content []byte) bool {
	limit := len(content)
	if limit > 8192 {
		limit = 8192
	}
	return bytes.ContainsRune(content[:limit], 0)
}

// verifySecretRemovedScoped re-scans git objects for the given pattern after a
// scrub rewrite. When scope is non-nil, only blob matches at paths matching the
// scope glob are considered failures; out-of-scope blobs are expected to still
// contain the pattern. Non-blob matches (commit messages, tags) are always
// checked regardless of scope.
//
// This is TIER B, and its scope filter is WIDER than Tier A's on purpose --
// verifyPatternAbsentFromTips filters by the attributed path alone, while this
// one also consults the scoped-blob set built from every ref. Both halves of
// that difference are forced:
//
//   - attribution records ONE path per blob, and a blob really can sit at
//     several. Tier A has only that one path to judge by, so a blob whose
//     recorded path is out of scope while another of its paths is in scope
//     reads as out of scope there;
//   - the scoped-blob set cannot be built at Tier A time. It enumerates
//     `rev-list --all --objects`, which reads the refs as they stand BEFORE the
//     rewrite is published -- pre-move paths, not the ones the rewrite produced
//     -- so at Tier A it would answer about the wrong history entirely. Tier B
//     runs after the refs have moved, where the same enumeration is about the
//     history that now exists.
//
// The asymmetry errs PERMISSIVE at Tier A and strict here, which is the safe
// direction: a dual-path blob that Tier A lets through is caught by this check
// instead, so the outcome escalates from a Tier A refusal (exit 30, nothing
// happened) to a Tier B finding (exit 31, the rewrite stands and is reported
// incomplete). It never slips through unreported.
//
// objectTypes, when not nil, names the object types ("blob", "commit", "tag")
// whose matches count: a recipe operation answers only for what it rewrites.
func verifySecretRemovedScoped(ctx context.Context, pattern *regexp.Regexp, scope *string, objectTypes map[string]bool) error {
	if scope == nil && objectTypes == nil {
		return verifySecretRemoved(ctx, pattern)
	}

	verifyOpts := scan.ScanOpts{EntireHistory: true}
	results, err := scan.ScanObjects(ctx, pattern, verifyOpts)
	if err != nil {
		return fmt.Errorf("re-scan failed: %w", err)
	}
	if objectTypes != nil {
		kept := results.Matches[:0]
		for _, m := range results.Matches {
			if objectTypes[m.ObjectType] {
				kept = append(kept, m)
			}
		}
		results.Matches = kept
	}
	if len(results.Matches) == 0 {
		return nil
	}
	if scope == nil {
		return fmt.Errorf("%s", describeSurvivingMatches(ctx, results.Matches))
	}

	// Add attribution so blob matches have paths.
	if err := scan.AddAttribution(ctx, results, verifyOpts); err != nil {
		return fmt.Errorf("adding attribution for verification: %w", err)
	}

	// Also build the scoped blob set to check blobs by SHA (some blobs may
	// appear at multiple paths, and attribution only records one).
	scopedBlobs, err := buildScopedBlobSet(ctx, *scope)
	if err != nil {
		return fmt.Errorf("building scoped blob set for verification: %w", err)
	}

	var failures []scan.Match
	for _, m := range results.Matches {
		switch m.ObjectType {
		case "blob":
			// Only report blobs that are in scope (by path match or by SHA).
			if matchScope(*scope, m.Path) || scopedBlobs[m.SHA] {
				failures = append(failures, m)
			}
		default:
			// Commit messages and tags are always checked.
			failures = append(failures, m)
		}
	}

	if len(failures) == 0 {
		return nil
	}
	return fmt.Errorf("%s", describeSurvivingMatches(ctx, failures))
}

// matchScope checks whether a file path matches a glob scope pattern.
// It tries path.Match against both the full path and the basename, so
// patterns like "*.env" match "config/secret.env" as well as "secret.env".
func matchScope(scope, filePath string) bool {
	if filePath == "" {
		return false
	}
	// Try matching against the full path first (supports patterns like "config/**").
	if matched, _ := path.Match(scope, filePath); matched {
		return true
	}
	// Try matching against just the filename (supports patterns like "*.env").
	base := path.Base(filePath)
	if matched, _ := path.Match(scope, base); matched {
		return true
	}
	return false
}

// buildScopedBlobSet enumerates all blob-to-path mappings across all refs
// using `git rev-list --all --objects` and returns the set of blob SHAs that
// appear at paths matching the scope glob.
func buildScopedBlobSet(ctx context.Context, scope string) (map[string]bool, error) {
	stdout, _, err := git.Run(ctx, "rev-list", "--all", "--objects")
	if err != nil {
		return nil, fmt.Errorf("rev-list --all --objects: %w", err)
	}

	result := make(map[string]bool)
	for _, line := range strings.Split(stdout, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		spaceIdx := strings.IndexByte(line, ' ')
		if spaceIdx < 0 {
			// No space: this is a commit SHA, skip.
			continue
		}
		sha := line[:spaceIdx]
		filePath := line[spaceIdx+1:]
		if matchScope(scope, filePath) {
			result[sha] = true
		}
	}
	return result, nil
}

// mangleBytes replaces each non-whitespace byte in match with a random
// printable ASCII character (0x21-0x7E). Whitespace characters (space, tab,
// newline, carriage return) are preserved to maintain formatting structure.
// Uses crypto/rand for security.
func mangleBytes(match []byte) []byte {
	const printable = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
	result := make([]byte, len(match))
	for i, b := range match {
		switch b {
		case ' ', '\t', '\n', '\r':
			result[i] = b
		default:
			idx := make([]byte, 1)
			crypto_rand.Read(idx)
			result[i] = printable[int(idx[0])%len(printable)]
		}
	}
	return result
}
