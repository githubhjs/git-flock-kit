package test

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/stricttools/safegit/internal/exitcode"
	"github.com/stricttools/safegit/internal/testutil"
)

// `safegit commit --amend` (and its no-files spelling, reword) shares the
// commit pipeline's path machinery: internal/commit/amend.go:81 calls the same
// resolveFiles as commit, and amend.go:171 re-runs the same detectMoves. Every
// defect class pinned for plain commit therefore has an amend-flavored twin,
// and none of them was covered.
//
// Two things are unique to amend and covered only here:
//
//   - Parent reconstruction. tryAmend resolves ONE parent with
//     git.RevParse(ctx, ref+"^") (amend.go:125) and hands it to
//     git.CommitTree (amend.go:185), whose signature carries a single
//     parentSHA and emits at most one -p (internal/git/git.go:163-167).
//     tryReword does the same at amend.go:343 and amend.go:349. Amending a
//     MERGE commit therefore rebuilds it with only its first parent: the
//     merged branch is silently unmerged and its history detaches from the
//     line. git preserves every parent across `git commit --amend` (verified:
//     amending a two-parent commit, with and without new files, keeps both).
//
//   - Amending while a merge or cherry-pick is in progress. git refuses
//     outright -- "fatal: You are in the middle of a merge -- cannot amend."
//     (exit 128), and the same for a cherry-pick -- regardless of whether the
//     conflict has been staged. Nothing in the amend pipeline reads MERGE_HEAD
//     or CHERRY_PICK_HEAD.
//
// The git, filesystem and rev-reading helpers this file uses are the shared
// ones in internal/testutil; the conflicted-merge fixture is the shared
// newConflictedMergeRepo. Only amendParStatus below is local, and it stays
// prefixed so it cannot collide with the other investigations in this package.

// amendParStatus returns `git status --porcelain`, trimmed.
func amendParStatus(t *testing.T, dir string) string {
	t.Helper()
	out, _ := testutil.GitTry(t, dir, "status", "--porcelain")
	return strings.TrimSpace(out)
}

// ---------------------------------------------------------------------------
// Class 1: symlink collapse
// ---------------------------------------------------------------------------

// A symlink named on `safegit commit --amend` must enter the amended commit as
// the symlink object itself (mode 120000 whose blob is the link target), not
// resolved away to whatever it points at.
//
// resolveFiles (internal/commit/commit.go:387) runs resolveSymlinks over the
// full path INCLUDING the final component, so the argument "link" becomes the
// absolute path of "file.txt". Amend calls that same resolveFiles at
// amend.go:81, so the amended commit re-stages file.txt -- already in the tree
// being amended, unchanged -- and never records the link at all. Unlike plain
// commit there is no tree-unchanged refusal on the amend path, so the command
// exits 0 having silently dropped the argument.
func TestAmendSymlink_LinkToCommittedFile(t *testing.T) {
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "file.txt", "target content\n")
	safegitCommit(t, dir, "add file.txt", "file.txt")

	testutil.WriteFile(t, dir, "tip.txt", "tip\n")
	tip := safegitCommit(t, dir, "tip", "tip.txt")
	tipParent := testutil.Parents(t, dir, tip)

	if err := os.Symlink("file.txt", filepath.Join(dir, "link")); err != nil {
		t.Fatalf("creating symlink: %v", err)
	}

	stdout, stderr, code := runSafegit(t, dir, "commit", "--amend", "-m", "tip plus link", "--", "link")
	if code != 0 {
		t.Fatalf("amending in a symlink failed (code %d)\nstdout: %s\nstderr: %s", code, stdout, stderr)
	}

	head := testutil.Rev(t, dir, "HEAD")
	if head == tip {
		t.Fatalf("HEAD did not move; the amend produced no new commit")
	}
	if got := testutil.Parents(t, dir, head); strings.Join(got, ",") != strings.Join(tipParent, ",") {
		t.Errorf("amended commit parents = %v, want %v (the amended commit must replace the tip, not extend it)", got, tipParent)
	}

	// The symlink must be in the amended tree, as a symlink.
	mode := ""
	for _, line := range strings.Split(testutil.GitRaw(t, dir, "ls-tree", "-r", "HEAD"), "\n") {
		tab := strings.IndexByte(line, '\t')
		if tab < 0 || line[tab+1:] != "link" {
			continue
		}
		mode = strings.Fields(line[:tab])[0]
	}
	if mode != "120000" {
		t.Fatalf("expected HEAD entry %q with mode 120000, got mode %q; tree:\n%s",
			"link", mode, testutil.GitRaw(t, dir, "ls-tree", "-r", "HEAD"))
	}
	if target := testutil.GitRaw(t, dir, "cat-file", "blob", "HEAD:link"); target != "file.txt" {
		t.Errorf("symlink blob = %q, want the link target %q", target, "file.txt")
	}

	info, err := os.Lstat(filepath.Join(dir, "link"))
	if err != nil {
		t.Fatalf("lstat link: %v", err)
	}
	if info.Mode()&os.ModeSymlink == 0 {
		t.Errorf("link must remain a symlink on disk, got mode %v", info.Mode())
	}
}

// ---------------------------------------------------------------------------
// Class 2: directory pathspec + a blob-matching new file
// ---------------------------------------------------------------------------

// Amending a directory pathspec whose files were deleted and pre-staged, in the
// same amend as a new file that shares a blob with one of them, must succeed.
//
// It is the plain-commit shape reached through amend. stageFile drops the whole
// directory from the temp index, and move DETECTION -- which the amend path ran
// too, and which safegit no longer has at all -- then independently issued
// `git rm --cached` for an individual path inside that directory that was
// already gone from the index, which git rejects. A move is declared now, never
// guessed from a shared blob, so the amend is the ordinary one.
func TestAmendStagedDeletions_DirectoryPathWithMovedFile(t *testing.T) {
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "dir/a.txt", "alpha\n")
	testutil.WriteFile(t, dir, "dir/b.txt", "beta\n")
	base := safegitCommit(t, dir, "add dir", "dir/a.txt", "dir/b.txt")

	testutil.WriteFile(t, dir, "tip.txt", "tip\n")
	safegitCommit(t, dir, "tip", "tip.txt")

	// The external deletion tool: removes the files and stages the deletions.
	testutil.GitRaw(t, dir, "rm", "-r", "dir")

	// dir/a.txt reappears at the root with identical content, so move
	// detection fires.
	testutil.WriteFile(t, dir, "new.txt", "alpha\n")

	stdout, stderr, code := runSafegit(t, dir, "commit", "--amend", "-m", "tip, move a out of dir", "--", "dir/", "new.txt")
	if code != 0 {
		t.Fatalf("amending a directory of staged deletions alongside a moved file failed (code %d)\nstdout: %s\nstderr: %s",
			code, stdout, stderr)
	}

	head := testutil.Rev(t, dir, "HEAD")
	if parents := testutil.Parents(t, dir, head); len(parents) != 1 || parents[0] != base {
		t.Errorf("amended commit parents = %v, want [%s]", parents, base)
	}

	paths := testutil.TreePaths(t, dir, "HEAD")
	for _, gone := range []string{"dir/a.txt", "dir/b.txt"} {
		if testutil.Contains(paths, gone) {
			t.Errorf("%s should be absent from the amended tree, got: %v", gone, paths)
		}
	}
	for _, want := range []string{"new.txt", "tip.txt"} {
		if !testutil.Contains(paths, want) {
			t.Errorf("%s missing from the amended tree, got: %v", want, paths)
		}
	}
	if status := amendParStatus(t, dir); status != "" {
		t.Errorf("expected a clean working tree after the amend, got: %s", status)
	}
}

// The same shape with no deliberate move: an empty file deleted with the
// directory and an unrelated new empty file share the empty blob, which is all
// it takes for move detection to fire.
func TestAmendStagedDeletions_DirectoryPathWithUnrelatedEmptyFile(t *testing.T) {
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "dir/empty.txt", "")
	testutil.WriteFile(t, dir, "dir/b.txt", "beta\n")
	safegitCommit(t, dir, "add dir", "dir/empty.txt", "dir/b.txt")

	testutil.WriteFile(t, dir, "tip.txt", "tip\n")
	safegitCommit(t, dir, "tip", "tip.txt")

	testutil.GitRaw(t, dir, "rm", "-r", "dir")
	testutil.WriteFile(t, dir, "notes.md", "")

	stdout, stderr, code := runSafegit(t, dir, "commit", "--amend", "-m", "tip, remove dir, add notes", "--", "dir/", "notes.md")
	if code != 0 {
		t.Fatalf("amending a directory of staged deletions alongside an unrelated empty file failed (code %d)\nstdout: %s\nstderr: %s",
			code, stdout, stderr)
	}

	paths := testutil.TreePaths(t, dir, "HEAD")
	for _, gone := range []string{"dir/empty.txt", "dir/b.txt"} {
		if testutil.Contains(paths, gone) {
			t.Errorf("%s should be absent from the amended tree, got: %v", gone, paths)
		}
	}
	if !testutil.Contains(paths, "notes.md") {
		t.Errorf("notes.md missing from the amended tree, got: %v", paths)
	}
}

// The control: naming the individual file paths instead of the directory takes
// the branch move detection skips, and must keep working after any fix.
func TestAmendStagedDeletions_FilePathsWithMovedFile(t *testing.T) {
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "dir/a.txt", "alpha\n")
	testutil.WriteFile(t, dir, "dir/b.txt", "beta\n")
	safegitCommit(t, dir, "add dir", "dir/a.txt", "dir/b.txt")

	testutil.WriteFile(t, dir, "tip.txt", "tip\n")
	safegitCommit(t, dir, "tip", "tip.txt")

	testutil.GitRaw(t, dir, "rm", "-r", "dir")
	testutil.WriteFile(t, dir, "new.txt", "alpha\n")

	stdout, stderr, code := runSafegit(t, dir, "commit", "--amend", "-m", "tip, move a out of dir", "--",
		"dir/a.txt", "dir/b.txt", "new.txt")
	if code != 0 {
		t.Fatalf("amending staged deletions by file path failed (code %d)\nstdout: %s\nstderr: %s", code, stdout, stderr)
	}

	paths := testutil.TreePaths(t, dir, "HEAD")
	for _, gone := range []string{"dir/a.txt", "dir/b.txt"} {
		if testutil.Contains(paths, gone) {
			t.Errorf("%s should be absent from the amended tree, got: %v", gone, paths)
		}
	}
	if !testutil.Contains(paths, "new.txt") {
		t.Errorf("new.txt missing from the amended tree, got: %v", paths)
	}
}

// ---------------------------------------------------------------------------
// Class 3: subdirectory-relative path with no pending change
// ---------------------------------------------------------------------------

// Invoked from a repository subdirectory with two cwd-relative arguments, one
// of which has no pending change, `commit --amend` must resolve both against
// the invoking cwd. The unchanged one changes nothing about the tip being
// replaced, so it is refused by the name the caller typed -- and the amend does
// not happen at all, leaving the tip and the unchanged file exactly as they
// were.
func TestAmendFromSubdirRelativePathNoPendingChange(t *testing.T) {
	dir := newRepo(t)
	sub := filepath.Join(dir, "sub")

	testutil.WriteFile(t, dir, "sub/unchanged.txt", "unchanged\n")
	testutil.WriteFile(t, dir, "sub/edited.txt", "before\n")
	safegitCommit(t, dir, "add sub files", "sub/unchanged.txt", "sub/edited.txt")

	testutil.WriteFile(t, dir, "tip.txt", "tip\n")
	tip := safegitCommit(t, dir, "tip", "tip.txt")
	tipParents := testutil.Parents(t, dir, tip)

	testutil.WriteFile(t, dir, "sub/edited.txt", "after\n")

	stdout, stderr, code := runSafegit(t, sub, "commit", "--amend", "-m", "tip plus subdir edit", "--",
		"edited.txt", "unchanged.txt")
	if code != exitcode.PathMatchedNothing {
		t.Fatalf("amending from a subdirectory with an unchanged relative path exited %d, want %d\nstdout:\n%s\nstderr:\n%s",
			code, exitcode.PathMatchedNothing, stdout, stderr)
	}
	// Naming the argument as typed is what proves it was resolved against sub/
	// rather than against the repository root.
	if !strings.Contains(stderr, "unchanged.txt") {
		t.Errorf("the refusal does not name the argument it was decided about: %s", stderr)
	}
	if got := testutil.Rev(t, dir, "HEAD"); got != tip {
		t.Errorf("the tip moved despite the refusal: %s -> %s", tip, got)
	}

	// The same command without the unchanged argument amends normally.
	if _, stderr, code := runSafegit(t, sub, "commit", "--amend", "-m", "tip plus subdir edit", "--", "edited.txt"); code != 0 {
		t.Fatalf("amending the changed path alone failed (code %d): %s", code, stderr)
	}
	if got := testutil.Parents(t, dir, "HEAD"); strings.Join(got, ",") != strings.Join(tipParents, ",") {
		t.Errorf("amended commit parents = %v, want %v", got, tipParents)
	}
	if got, ok := testutil.Show(t, dir, "HEAD", "sub/edited.txt"); !ok || got != "after\n" {
		t.Errorf("sub/edited.txt at HEAD = %q (present=%t), want %q", got, ok, "after\n")
	}
	if got, ok := testutil.Show(t, dir, "HEAD", "sub/unchanged.txt"); !ok || got != "unchanged\n" {
		t.Errorf("sub/unchanged.txt at HEAD = %q (present=%t): an amend must never remove a path it did not touch", got, ok)
	}
	if status := amendParStatus(t, dir); status != "" {
		t.Errorf("expected a clean working tree after the amend, got: %s", status)
	}
}

// The control from the repository root, where relative and repo-relative
// spellings coincide: the same refusal, so a difference between the two
// directories is a path-resolution defect rather than the refusal itself.
func TestAmendFromRepoRootUnchangedPath(t *testing.T) {
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "unchanged.txt", "unchanged\n")
	testutil.WriteFile(t, dir, "edited.txt", "before\n")
	safegitCommit(t, dir, "add root files", "unchanged.txt", "edited.txt")

	testutil.WriteFile(t, dir, "tip.txt", "tip\n")
	tip := safegitCommit(t, dir, "tip", "tip.txt")

	testutil.WriteFile(t, dir, "edited.txt", "after\n")

	stdout, stderr, code := runSafegit(t, dir, "commit", "--amend", "-m", "tip plus root edit", "--",
		"edited.txt", "unchanged.txt")
	if code != exitcode.PathMatchedNothing {
		t.Fatalf("amending from the repo root with an unchanged path exited %d, want %d\nstdout:\n%s\nstderr:\n%s",
			code, exitcode.PathMatchedNothing, stdout, stderr)
	}
	if !strings.Contains(stderr, "unchanged.txt") {
		t.Errorf("the refusal does not name the argument it was decided about: %s", stderr)
	}
	if got := testutil.Rev(t, dir, "HEAD"); got != tip {
		t.Errorf("the tip moved despite the refusal: %s -> %s", tip, got)
	}

	if _, stderr, code := runSafegit(t, dir, "commit", "--amend", "-m", "tip plus root edit", "--", "edited.txt"); code != 0 {
		t.Fatalf("amending the changed path alone failed (code %d): %s", code, stderr)
	}
	if got, ok := testutil.Show(t, dir, "HEAD", "edited.txt"); !ok || got != "after\n" {
		t.Errorf("edited.txt at HEAD = %q (present=%t), want %q", got, ok, "after\n")
	}
	if got, ok := testutil.Show(t, dir, "HEAD", "unchanged.txt"); !ok || got != "unchanged\n" {
		t.Errorf("unchanged.txt at HEAD = %q (present=%t), want %q", got, ok, "unchanged\n")
	}
}

// ---------------------------------------------------------------------------
// Class 4: untracking on the amend path
// ---------------------------------------------------------------------------

// The untrack cleanup -- add the pattern to .gitignore, drop the tracked
// copies, record both in one commit -- reaches amend through the same flag it
// reaches commit through. Amend shares intake with commit, so the flag is the
// same flag; what this pins is that it is wired on both paths and judged
// against the tip being REPLACED.
func TestAmendUntrackGitignoredPath(t *testing.T) {
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "dir/junk.txt", "build artifact\n")
	safegitCommit(t, dir, "add junk", "dir/junk.txt")

	testutil.WriteFile(t, dir, "tip.txt", "tip\n")
	safegitCommit(t, dir, "tip", "tip.txt")

	// The pattern that makes the tracked file ignored from now on. The index
	// entry stays: dropping it is what --untrack is being asked to do, and a
	// fixture that drops it first would also make the notice assertion below
	// vacuous, since the not-gitignored question has the opposite index-aware
	// answer for a path still in the index.
	testutil.WriteFile(t, dir, ".gitignore", "dir/\n")

	stdout, stderr, code := runSafegit(t, dir, "commit", "--amend", "-m", "tip, untrack dir",
		"--untrack", "dir/junk.txt", "--", ".gitignore")
	if code != 0 {
		t.Fatalf("amending the untrack cleanup failed (code %d)\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}
	if strings.Contains(stderr, "not gitignored") {
		t.Errorf("untracking an already-ignored path must not suggest a .gitignore pattern; stderr:\n%s", stderr)
	}

	paths := testutil.TreePaths(t, dir, "HEAD")
	if !testutil.Contains(paths, ".gitignore") {
		t.Errorf(".gitignore missing from the amended tree, got: %v", paths)
	}
	if testutil.Contains(paths, "dir/junk.txt") {
		t.Errorf("dir/junk.txt should no longer be tracked, amended tree: %v", paths)
	}
	if _, err := os.Stat(filepath.Join(dir, "dir", "junk.txt")); err != nil {
		t.Errorf("dir/junk.txt must remain on disk after being untracked: %v", err)
	}
}

// The cross-branch amend sharpens the same class of check. resolveFiles answers
// "is this path tracked?" with git.IsTracked (internal/commit/commit.go:402),
// which reads the CURRENT branch's index -- but `--amend --branch other`
// rebuilds a commit on `other`, seeding its temp index from that branch's tip
// (amend.go:150). A path that is tracked on `other` and absent from both the
// working tree and the current branch is therefore rejected as "does not exist
// and is not tracked by git", even though the operation -- record its deletion
// on the target branch -- is exactly what the tracked check should have
// allowed. The check answers a question about the wrong ref.
func TestAmendCrossBranchDeletionOfPathTrackedOnlyOnTarget(t *testing.T) {
	dir := newRepo(t)

	// `other` carries only-on-other.txt; main never sees it.
	testutil.GitRaw(t, dir, "branch", "other")
	testutil.GitRaw(t, dir, "switch", "other")
	testutil.WriteFile(t, dir, "only-on-other.txt", "other content\n")
	otherTip := safegitCommit(t, dir, "add only-on-other", "only-on-other.txt")
	otherParents := testutil.Parents(t, dir, otherTip)

	testutil.GitRaw(t, dir, "switch", "main")
	if _, err := os.Stat(filepath.Join(dir, "only-on-other.txt")); !os.IsNotExist(err) {
		t.Fatalf("fixture: only-on-other.txt must be absent from main's working tree, stat err = %v", err)
	}

	stdout, stderr, code := runSafegit(t, dir, "commit", "--amend", "--branch", "other",
		"-m", "add only-on-other (dropped again)", "--", "only-on-other.txt")
	if code != 0 {
		t.Fatalf("cross-branch amend recording a deletion of a path tracked only on the target branch "+
			"failed (code %d)\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}

	if got := testutil.Parents(t, dir, "refs/heads/other"); strings.Join(got, ",") != strings.Join(otherParents, ",") {
		t.Errorf("other's amended tip parents = %v, want %v", got, otherParents)
	}
	if paths := testutil.TreePaths(t, dir, "refs/heads/other"); testutil.Contains(paths, "only-on-other.txt") {
		t.Errorf("only-on-other.txt should be gone from other's amended tip, got: %v", paths)
	}
	if head := testutil.Rev(t, dir, "HEAD"); head != testutil.Rev(t, dir, "refs/heads/main") {
		t.Errorf("HEAD left main during a cross-branch amend")
	}
}

// ---------------------------------------------------------------------------
// Class 5: merge commits
// ---------------------------------------------------------------------------

// amendParMergeFixture is a repository whose tip is a genuine two-parent merge
// commit, produced through safegit's own merge.
type amendParMergeFixture struct {
	dir        string
	mergeSHA   string
	mainSHA    string // first parent
	featureSHA string // second parent
}

// amendParNewMergedRepo builds main and feature diverging on different files
// (so the merge cannot fast-forward) and merges feature into main cleanly.
func amendParNewMergedRepo(t *testing.T) amendParMergeFixture {
	t.Helper()
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "base.txt", "base\n")
	safegitCommit(t, dir, "base", "base.txt")

	testutil.GitRaw(t, dir, "branch", "feature")
	testutil.GitRaw(t, dir, "switch", "feature")
	testutil.WriteFile(t, dir, "f.txt", "feature\n")
	featureSHA := safegitCommit(t, dir, "feature edit", "f.txt")

	testutil.GitRaw(t, dir, "switch", "main")
	testutil.WriteFile(t, dir, "m.txt", "main\n")
	mainSHA := safegitCommit(t, dir, "main edit", "m.txt")

	stdout, stderr, code := runSafegit(t, dir, "merge", "feature")
	if code != 0 {
		t.Fatalf("safegit merge feature failed (code %d)\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}

	mergeSHA := testutil.Rev(t, dir, "HEAD")
	parents := testutil.Parents(t, dir, mergeSHA)
	if len(parents) != 2 || parents[0] != mainSHA || parents[1] != featureSHA {
		t.Fatalf("fixture: HEAD is not the expected merge commit; parents = %v, want [%s %s]",
			parents, mainSHA, featureSHA)
	}
	return amendParMergeFixture{dir: dir, mergeSHA: mergeSHA, mainSHA: mainSHA, featureSHA: featureSHA}
}

// Rewording a merge commit keeps both parents, exactly as `git commit --amend
// -m` does. Reword reads EVERY parent off the commit object being replaced and
// hands the whole list to git.CommitTree.
//
// It once resolved a single parent with `ref^` and passed it to a CommitTree
// that could only express one -p, so a reworded merge came out with one parent
// and the merged branch was silently unmerged. That is what this test exists to
// keep from coming back.
func TestRewordMergeCommitPreservesBothParents(t *testing.T) {
	fx := amendParNewMergedRepo(t)

	stdout, stderr, code := runSafegit(t, fx.dir, "commit", "--amend", "-m", "Merge feature (reworded)")
	if code != 0 {
		t.Fatalf("rewording a merge commit failed (code %d)\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}

	head := testutil.Rev(t, fx.dir, "HEAD")
	parents := testutil.Parents(t, fx.dir, head)
	if len(parents) != 2 {
		t.Fatalf("reworded merge commit has %d parent(s) (%v), want 2 (%s, %s): the second parent was dropped, "+
			"so feature is no longer merged into main",
			len(parents), parents, fx.mainSHA, fx.featureSHA)
	}
	if parents[0] != fx.mainSHA {
		t.Errorf("first parent = %s, want %s", parents[0], fx.mainSHA)
	}
	if parents[1] != fx.featureSHA {
		t.Errorf("second parent = %s, want %s", parents[1], fx.featureSHA)
	}

	// A reword changes nothing but the message.
	if got, want := testutil.Rev(t, fx.dir, "HEAD^{tree}"), testutil.Rev(t, fx.dir, fx.mergeSHA+"^{tree}"); got != want {
		t.Errorf("reworded tree = %s, want the merge's own tree %s", got, want)
	}
	if msg := testutil.GitRaw(t, fx.dir, "log", "-1", "--format=%s"); !strings.Contains(msg, "reworded") {
		t.Errorf("message was not reworded: %q", strings.TrimSpace(msg))
	}
	// feature must still be an ancestor of the tip.
	if _, code := testutil.GitTry(t, fx.dir, "merge-base", "--is-ancestor", fx.featureSHA, "HEAD"); code != 0 {
		t.Errorf("feature (%s) is no longer an ancestor of the reworded tip", fx.featureSHA)
	}
}

// Amending a merge commit WITH new files likewise keeps both parents, as `git
// commit --amend` with staged changes does. tryAmend reads the tip's whole
// parent list off the commit object and builds the replacement on all of it;
// naming only the first would silently unmerge the branch that was merged in.
func TestAmendMergeCommitWithFilesPreservesBothParents(t *testing.T) {
	fx := amendParNewMergedRepo(t)

	testutil.WriteFile(t, fx.dir, "extra.txt", "extra\n")

	stdout, stderr, code := runSafegit(t, fx.dir, "commit", "--amend", "-m", "Merge feature plus extra", "--", "extra.txt")
	if code != 0 {
		t.Fatalf("amending a merge commit with a new file failed (code %d)\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}

	head := testutil.Rev(t, fx.dir, "HEAD")
	parents := testutil.Parents(t, fx.dir, head)
	if len(parents) != 2 {
		t.Fatalf("amended merge commit has %d parent(s) (%v), want 2 (%s, %s): the second parent was dropped",
			len(parents), parents, fx.mainSHA, fx.featureSHA)
	}
	if parents[0] != fx.mainSHA || parents[1] != fx.featureSHA {
		t.Errorf("parents = %v, want [%s %s]", parents, fx.mainSHA, fx.featureSHA)
	}

	paths := testutil.TreePaths(t, fx.dir, "HEAD")
	for _, want := range []string{"extra.txt", "m.txt", "f.txt", "base.txt"} {
		if !testutil.Contains(paths, want) {
			t.Errorf("%s missing from the amended merge tree, got: %v", want, paths)
		}
	}
	if _, code := testutil.GitTry(t, fx.dir, "merge-base", "--is-ancestor", fx.featureSHA, "HEAD"); code != 0 {
		t.Errorf("feature (%s) is no longer an ancestor of the amended tip", fx.featureSHA)
	}
}

// The cross-branch spelling reaches the same single-parent reconstruction on a
// branch that is not checked out, where nothing in the working tree hints that
// a merge was just undone.
func TestRewordMergeCommitCrossBranchPreservesBothParents(t *testing.T) {
	fx := amendParNewMergedRepo(t)

	// Step off main so the reword targets a branch that is not HEAD.
	testutil.GitRaw(t, fx.dir, "switch", "feature")

	stdout, stderr, code := runSafegit(t, fx.dir, "commit", "--amend", "--branch", "main",
		"-m", "Merge feature (reworded cross-branch)")
	if code != 0 {
		t.Fatalf("cross-branch reword of a merge commit failed (code %d)\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}

	parents := testutil.Parents(t, fx.dir, "refs/heads/main")
	if len(parents) != 2 {
		t.Fatalf("cross-branch reworded merge commit has %d parent(s) (%v), want 2 (%s, %s)",
			len(parents), parents, fx.mainSHA, fx.featureSHA)
	}
	if parents[0] != fx.mainSHA || parents[1] != fx.featureSHA {
		t.Errorf("parents = %v, want [%s %s]", parents, fx.mainSHA, fx.featureSHA)
	}
}

// ---------------------------------------------------------------------------
// Class 5b: amending while a merge or cherry-pick is in progress
// ---------------------------------------------------------------------------

// git refuses `git commit --amend` outright while a merge is in progress:
//
//	fatal: You are in the middle of a merge -- cannot amend.
//
// It refuses whether or not the resolution has been staged, because the amended
// commit would replace the tip the merge is being built on top of while
// MERGE_HEAD still points at the other side. safegit must refuse too. Nothing
// in Amend or Reword reads MERGE_HEAD, so both spellings run and rewrite the
// tip out from under the merge.
func TestAmendRefusedWhileMerging(t *testing.T) {
	for _, tc := range []struct {
		name string
		args []string
	}{
		{"reword", []string{"commit", "--amend", "-m", "rewritten mid-merge"}},
		{"amend-with-file", []string{"commit", "--amend", "-m", "rewritten mid-merge", "--", "conflicted.txt"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			fx := newConflictedMergeRepo(t, conflictedMergeOpts{resolveInTree: true})
			dir, mainSHA, featureSHA := fx.dir, fx.mainSHA, fx.featureSHA

			// git's own refusal, recorded so the test documents the contract
			// safegit is expected to match.
			gitOut, gitCode := testutil.GitTry(t, dir, "commit", "--amend", "-m", "rewritten mid-merge")
			if gitCode == 0 {
				t.Fatalf("git commit --amend mid-merge succeeded; expected a refusal\n%s", gitOut)
			}
			if !strings.Contains(gitOut, "cannot amend") {
				t.Fatalf("git refused for an unexpected reason (code %d): %s", gitCode, strings.Join(strings.Fields(gitOut), " "))
			}

			before := testutil.Rev(t, dir, "HEAD")
			if before != mainSHA {
				t.Fatalf("fixture: HEAD = %s, want the pre-merge main tip %s", before, mainSHA)
			}

			stdout, stderr, code := runSafegit(t, dir, tc.args...)
			if code == 0 {
				head := testutil.Rev(t, dir, "HEAD")
				t.Fatalf("safegit %s succeeded mid-merge (git refuses the same command).\n"+
					"  new tip: %s (was %s)\n"+
					"  parents: %v\n"+
					"  tree: %v\n"+
					"  MERGE_HEAD still present: %t\n"+
					"  stdout: %s",
					strings.Join(tc.args, " "), head, before,
					testutil.Parents(t, dir, head), testutil.TreePaths(t, dir, "HEAD"),
					!testutil.MergeStateGone(t, dir), strings.Join(strings.Fields(stdout), " "))
			}

			if head := testutil.Rev(t, dir, "HEAD"); head != before {
				t.Errorf("HEAD moved to %s despite the refusal (was %s)", head, before)
			}
			testutil.AssertMergeHead(t, dir, featureSHA, ".git/MERGE_HEAD must survive a refused amend")
			if !strings.Contains(strings.ToLower(stderr), "merge") {
				t.Errorf("the refusal does not mention the merge: %s", strings.Join(strings.Fields(stderr), " "))
			}
			// The registry gives a coordination refusal its own code, so a
			// caller can tell "an operation owns this tree" from every other
			// reason an amend or a reword could fail.
			if code != exitcode.CoordinationBusy {
				t.Errorf("the refusal exited %d, want %d (CoordinationBusy): %s",
					code, exitcode.CoordinationBusy, strings.Join(strings.Fields(stderr), " "))
			}
		})
	}
}

// git refuses an amend during a cherry-pick for the same reason:
//
//	fatal: You are in the middle of a cherry-pick -- cannot amend.
//
// safegit's cherry-pick computes with `git cherry-pick --no-commit` and writes
// CHERRY_PICK_HEAD itself, so a conflicted pick parks in exactly the state
// git's own conflicted pick leaves -- which is what the amend pipeline reads
// when it refuses.
func TestAmendRefusedWhileCherryPicking(t *testing.T) {
	dir := newRepo(t)

	testutil.WriteFile(t, dir, "c.txt", "base\n")
	safegitCommit(t, dir, "base", "c.txt")

	testutil.GitRaw(t, dir, "branch", "feature")
	testutil.GitRaw(t, dir, "switch", "feature")
	testutil.WriteFile(t, dir, "c.txt", "feature\n")
	safegitCommit(t, dir, "feature edit", "c.txt")

	testutil.GitRaw(t, dir, "switch", "main")
	testutil.WriteFile(t, dir, "c.txt", "main\n")
	mainSHA := safegitCommit(t, dir, "main edit", "c.txt")

	stdout, stderr, code := runSafegit(t, dir, "cherry-pick", "feature")
	if code == 0 {
		t.Fatalf("fixture needs a cherry-pick conflict; it succeeded\nstdout=%s stderr=%s", stdout, stderr)
	}
	if _, err := os.Stat(filepath.Join(dir, ".git", "CHERRY_PICK_HEAD")); err != nil {
		t.Fatalf("fixture: .git/CHERRY_PICK_HEAD must exist after the conflict: %v", err)
	}

	gitOut, gitCode := testutil.GitTry(t, dir, "commit", "--amend", "-m", "rewritten mid-cherry-pick")
	if gitCode == 0 || !strings.Contains(gitOut, "cannot amend") {
		t.Fatalf("git commit --amend mid-cherry-pick did not refuse as expected (code %d): %s",
			gitCode, strings.Join(strings.Fields(gitOut), " "))
	}

	stdout, stderr, code = runSafegit(t, dir, "commit", "--amend", "-m", "rewritten mid-cherry-pick")
	if code == 0 {
		head := testutil.Rev(t, dir, "HEAD")
		t.Fatalf("safegit commit --amend succeeded mid-cherry-pick (git refuses the same command).\n"+
			"  new tip: %s (was %s)\n"+
			"  CHERRY_PICK_HEAD still present: %t\n"+
			"  stdout: %s",
			head, mainSHA,
			testutil.FileExists(filepath.Join(dir, ".git", "CHERRY_PICK_HEAD")),
			strings.Join(strings.Fields(stdout), " "))
	}
	if head := testutil.Rev(t, dir, "HEAD"); head != mainSHA {
		t.Errorf("HEAD moved to %s despite the refusal (was %s)", head, mainSHA)
	}
	if !strings.Contains(strings.ToLower(stderr), "cherry") {
		t.Errorf("the refusal does not mention the cherry-pick: %s", strings.Join(strings.Fields(stderr), " "))
	}
	if code != exitcode.CoordinationBusy {
		t.Errorf("the refusal exited %d, want %d (CoordinationBusy): %s",
			code, exitcode.CoordinationBusy, strings.Join(strings.Fields(stderr), " "))
	}
}
