package test

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/stricttools/safegit/internal/testutil"
)

// An UNBORN branch is the state a repository is in between `git init` and its
// first commit: HEAD names a branch no ref exists for, `git rev-parse HEAD`
// fails, and every git command that takes HEAD as a treeish is fatal. It is
// also the state `safegit undo` of a root commit leaves behind, and the state a
// fresh clone-by-fetch sits in before the first branch is checked out.
//
// Every guarded command used to refuse there, and not deliberately: the
// coordination check ran `git diff HEAD`, which is fatal, so switch, merge,
// pick, pull, reset and revert all died with git's "ambiguous argument 'HEAD'"
// before their own handlers decided anything.
//
// These tests pin what an unborn branch supports now, and what it deliberately
// refuses. The fixture shape is deliberate too: `git init` in an empty
// directory and then `git fetch <src> main:side`, which leaves HEAD unborn AND
// a branch present with commits on it. `git checkout --orphan` would NOT
// produce it -- its index keeps the old checkout's content, so the tree is
// dirty from the start.

// unbornFixture is a repository whose HEAD is unborn, holding a fetched branch
// `side` with two commits on it.
type unbornFixture struct {
	dir string
	// firstSHA creates file.txt; secondSHA modifies it. Picking the SECOND onto
	// the unborn head is a MODIFY/DELETE conflict, which is the only conflict an
	// unborn pick can have (an add-only pick applies cleanly onto nothing).
	firstSHA, secondSHA string
}

// newUnbornRepo builds the fixture. The source repository is thrown away except
// for the objects the fetch copied.
func newUnbornRepo(t *testing.T) unbornFixture {
	t.Helper()

	src := newRepo(t)
	testutil.WriteFile(t, src, "file.txt", "one\n")
	firstSHA := safegitCommit(t, src, "create file", "file.txt")
	testutil.WriteFile(t, src, "file.txt", "two\n")
	secondSHA := safegitCommit(t, src, "modify file", "file.txt")

	dir := evalTempDir(t)
	for _, args := range [][]string{
		{"init", "--initial-branch=main"},
		{"config", "user.email", "test@test.com"},
		{"config", "user.name", "Test"},
		{"fetch", src, "main:side"},
	} {
		testutil.Git(t, dir, args...)
	}

	if _, ok := testutil.GitTryOut(t, dir, "rev-parse", "--verify", "--quiet", "HEAD"); ok {
		t.Fatalf("fixture is not unborn: HEAD resolves")
	}
	if status := testutil.Git(t, dir, "status", "--porcelain"); strings.TrimSpace(status) != "" {
		t.Fatalf("fixture is not clean: %q", status)
	}
	return unbornFixture{dir: dir, firstSHA: firstSHA, secondSHA: secondSHA}
}

// readWorktreeFile reads a working-tree file as a string.
func readWorktreeFile(t *testing.T, dir, rel string) string {
	t.Helper()
	data, err := os.ReadFile(filepath.Join(dir, rel))
	if err != nil {
		t.Fatalf("reading %s: %v", rel, err)
	}
	return string(data)
}

// assertOplogOutcome checks that the newest entry for op carries the outcome.
func assertOplogOutcome(t *testing.T, dir, op, want string) {
	t.Helper()
	entries := oplogEntries(t, dir, op)
	if len(entries) == 0 {
		t.Fatalf("no oplog entry for op %q", op)
	}
	last := entries[len(entries)-1]
	extra, _ := last["extra"].(map[string]interface{})
	if extra["outcome"] != want {
		t.Errorf("oplog outcome = %v, want %q (entry: %v)", extra["outcome"], want, last)
	}
}

func TestUnbornMergeFastForwards(t *testing.T) {
	f := newUnbornRepo(t)

	stdout, stderr, code := runSafegit(t, f.dir, "merge", "side")
	if code != 0 {
		t.Fatalf("safegit merge side on an unborn branch: code %d\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}
	if !strings.Contains(stdout, "fast-forwarded") {
		t.Errorf("merge did not report a fast-forward.\nstdout=%s", stdout)
	}
	if head := testutil.Rev(t, f.dir, "HEAD"); head != f.secondSHA {
		t.Errorf("HEAD = %s, want the incoming tip %s", head, f.secondSHA)
	}
	// The sync is the half a bare ref move leaves undone: without it git reports
	// the incoming file as a staged deletion and it is missing from disk.
	if status := testutil.Git(t, f.dir, "status", "--porcelain"); strings.TrimSpace(status) != "" {
		t.Errorf("working tree not in step with the new tip: %q", status)
	}
	if _, err := os.Stat(filepath.Join(f.dir, "file.txt")); err != nil {
		t.Errorf("file.txt missing from the working tree after the fast-forward: %v", err)
	}
	assertOplogOutcome(t, f.dir, "merge", "fast-forward")
}

func TestUnbornSwitchBothForms(t *testing.T) {
	t.Run("onto an existing branch", func(t *testing.T) {
		f := newUnbornRepo(t)
		if _, stderr, code := runSafegit(t, f.dir, "switch", "side"); code != 0 {
			t.Fatalf("safegit switch side from an unborn HEAD: code %d\n%s", code, stderr)
		}
		if br := strings.TrimSpace(testutil.Git(t, f.dir, "symbolic-ref", "--short", "HEAD")); br != "side" {
			t.Errorf("on branch %q, want side", br)
		}
	})

	t.Run("creating a branch", func(t *testing.T) {
		f := newUnbornRepo(t)
		if _, stderr, code := runSafegit(t, f.dir, "switch", "-c", "fresh"); code != 0 {
			t.Fatalf("safegit switch -c fresh on an unborn HEAD: code %d\n%s", code, stderr)
		}
		if br := strings.TrimSpace(testutil.Git(t, f.dir, "symbolic-ref", "--short", "HEAD")); br != "fresh" {
			t.Errorf("on branch %q, want fresh", br)
		}
		// Still unborn: a branch created where there is no commit has no ref yet.
		if _, ok := testutil.GitTryOut(t, f.dir, "rev-parse", "--verify", "--quiet", "HEAD"); ok {
			t.Errorf("switch -c on an unborn HEAD created a commit")
		}
	})
}

func TestUnbornDirtyTreeRefusesWithBothPathsListed(t *testing.T) {
	f := newUnbornRepo(t)
	testutil.WriteFile(t, f.dir, "staged.txt", "staged\n")
	testutil.Git(t, f.dir, "add", "staged.txt")
	testutil.WriteFile(t, f.dir, "untracked.txt", "untracked\n")

	_, stderr, code := runSafegit(t, f.dir, "merge", "side")
	if code != 5 {
		t.Fatalf("dirty unborn merge exited %d, want 5 (CoordinationBusy)\n%s", code, stderr)
	}
	for _, want := range []string{"staged.txt", "untracked.txt", "working tree is not clean"} {
		if !strings.Contains(stderr, want) {
			t.Errorf("refusal missing %q:\n%s", want, stderr)
		}
	}
}

func TestUnbornCommitStillRoots(t *testing.T) {
	f := newUnbornRepo(t)
	testutil.WriteFile(t, f.dir, "new.txt", "new\n")

	if _, stderr, code := runSafegit(t, f.dir, "commit", "-m", "root", "--", "new.txt"); code != 0 {
		t.Fatalf("safegit commit on an unborn branch: code %d\n%s", code, stderr)
	}
	if n := gitLog(t, f.dir, "HEAD"); n != 1 {
		t.Errorf("commit count = %d, want 1 root commit", n)
	}
}

func TestUnbornCherryPickRootsWithTheAuthorPreserved(t *testing.T) {
	f := newUnbornRepo(t)

	stdout, stderr, code := runSafegit(t, f.dir, "cherry-pick", f.firstSHA)
	if code != 0 {
		t.Fatalf("safegit cherry-pick onto an unborn branch: code %d\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}
	if n := gitLog(t, f.dir, "HEAD"); n != 1 {
		t.Errorf("commit count = %d, want 1 (the pick is a ROOT commit here)", n)
	}
	author := strings.TrimSpace(testutil.Git(t, f.dir, "log", "-1", "--format=%an <%ae>"))
	sourceAuthor := strings.TrimSpace(testutil.Git(t, f.dir, "log", "-1", "--format=%an <%ae>", f.firstSHA))
	if author != sourceAuthor {
		t.Errorf("author = %q, want the source's %q", author, sourceAuthor)
	}
	if got := readWorktreeFile(t, f.dir, "file.txt"); got != "one\n" {
		t.Errorf("file.txt = %q, want the picked content", got)
	}
	assertNoSequencerResidue(t, f.dir, "after a clean unborn pick")
}

// The one path that exercises the substituted first-parent uses in marker
// verification: a conflicted pick onto an unborn head, concluded through
// safegit. The conflict must be MODIFY/DELETE, because an add-only pick onto
// nothing applies cleanly -- so the index holds stages 1 and 3 and NO stage 2,
// which is what the resolution declaration has to be written against.
func TestUnbornConflictedCherryPickParksAndConcludes(t *testing.T) {
	f := newUnbornRepo(t)

	_, stderr, code := runSafegit(t, f.dir, "cherry-pick", f.secondSHA)
	if code == 0 {
		t.Fatalf("cherry-pick of the modifying commit onto an unborn head succeeded; the fixture needs a conflict\n%s", stderr)
	}
	stages := strings.TrimSpace(testutil.Git(t, f.dir, "ls-files", "-u", "file.txt"))
	if stages == "" {
		t.Fatalf("no unmerged stages for file.txt; the pick did not park a conflict")
	}
	for _, line := range strings.Split(stages, "\n") {
		if strings.Contains(line, "\tfile.txt") && strings.Contains(line, " 2\t") {
			t.Errorf("unexpected stage 2 in a modify/delete conflict:\n%s", stages)
		}
	}

	// theirs is the picked content: keeping it is what an operator concluding
	// this conflict means by "apply the pick".
	stdout, stderr, code := runSafegit(t, f.dir, "cherry-pick-continue", "--resolve", "file.txt=theirs")
	if code != 0 {
		t.Fatalf("cherry-pick-continue on an unborn branch: code %d\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}
	if n := gitLog(t, f.dir, "HEAD"); n != 1 {
		t.Errorf("commit count = %d, want 1 (a conclusion onto an unborn head is a ROOT commit)", n)
	}
	if got := readWorktreeFile(t, f.dir, "file.txt"); got != "two\n" {
		t.Errorf("file.txt = %q, want the picked content", got)
	}
	assertNoSequencerResidue(t, f.dir, "after concluding an unborn pick")
}

func TestUnbornPullFastForwards(t *testing.T) {
	f := newUnbornRepo(t)
	// A remote whose branch is the one the fixture fetched: a pull is the merge
	// path with FETCH_HEAD as the incoming side.
	remote := newRepo(t)
	testutil.WriteFile(t, remote, "file.txt", "one\n")
	safegitCommit(t, remote, "create file", "file.txt")
	remoteTip := testutil.Rev(t, remote, "HEAD")
	testutil.Git(t, f.dir, "remote", "add", "origin", remote)

	stdout, stderr, code := runSafegit(t, f.dir, "pull", "--merge-strategy", "ff", "origin", "main")
	if code != 0 {
		t.Fatalf("safegit pull onto an unborn branch: code %d\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}
	if head := testutil.Rev(t, f.dir, "HEAD"); head != remoteTip {
		t.Errorf("HEAD = %s, want the fetched tip %s", head, remoteTip)
	}
	if status := testutil.Git(t, f.dir, "status", "--porcelain"); strings.TrimSpace(status) != "" {
		t.Errorf("working tree not in step with the pulled tip: %q", status)
	}
}

func TestUnbornResetHardWorks(t *testing.T) {
	f := newUnbornRepo(t)
	if _, stderr, code := runSafegit(t, f.dir, "reset", "--hard", "side"); code != 0 {
		t.Fatalf("safegit reset --hard side on an unborn branch: code %d\n%s", code, stderr)
	}
	if head := testutil.Rev(t, f.dir, "HEAD"); head != f.secondSHA {
		t.Errorf("HEAD = %s, want %s", head, f.secondSHA)
	}
}

// A revert onto an unborn head reverts nothing: there is no parent tree to put
// back, so the result is the empty tree and the standing empty-result refusal
// is the honest answer. Before the root-path comparison it minted a nonsense
// empty root commit instead.
func TestUnbornRevertRefusesAsEmpty(t *testing.T) {
	f := newUnbornRepo(t)

	stdout, stderr, code := runSafegit(t, f.dir, "revert", f.firstSHA)
	if code == 0 {
		t.Fatalf("revert onto an unborn head succeeded; it should refuse as empty\nstdout=%s\nstderr=%s", stdout, stderr)
	}
	if !strings.Contains(stdout+stderr, "no change") {
		t.Errorf("refusal does not say the revert produced no change:\nstdout=%s\nstderr=%s", stdout, stderr)
	}
	if _, ok := testutil.GitTryOut(t, f.dir, "rev-parse", "--verify", "--quiet", "HEAD"); ok {
		t.Errorf("the refused revert created a commit")
	}
	assertNoSequencerResidue(t, f.dir, "after a refused unborn revert")
}

// The friendly pre-flight refusals. Each names the situation (an unborn branch)
// and the way forward, and each fires BEFORE any git compute -- which for pull
// means before the fetch.
func TestUnbornFriendlyRefusals(t *testing.T) {
	cases := []struct {
		name string
		args []string
		want []string
	}{
		{"merge --no-commit", []string{"merge", "--no-commit", "side"}, []string{"unborn", "--no-commit"}},
		{"merge --no-ff", []string{"merge", "--no-ff", "side"}, []string{"unborn", "--no-ff"}},
		{"merge --no-ff under --dry-run", []string{"--dry-run", "merge", "--no-ff", "side"}, []string{"unborn", "--no-ff"}},
		{"rebase", []string{"rebase", "side"}, []string{"unborn", "rebase"}},
		{"bisect start", []string{"bisect", "start"}, []string{"unborn", "bisect"}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			f := newUnbornRepo(t)
			stdout, stderr, code := runSafegit(t, f.dir, tc.args...)
			if code == 0 {
				t.Fatalf("%v succeeded on an unborn branch; it should refuse\nstdout=%s\nstderr=%s", tc.args, stdout, stderr)
			}
			for _, want := range tc.want {
				if !strings.Contains(stderr, want) {
					t.Errorf("refusal missing %q:\n%s", want, stderr)
				}
			}
			// Nothing ran: no operation state, and the branch is still unborn.
			assertNoSequencerResidue(t, f.dir, "after a refused unborn "+tc.name)
			if _, ok := testutil.GitTryOut(t, f.dir, "rev-parse", "--verify", "--quiet", "HEAD"); ok {
				t.Errorf("the refused command moved HEAD")
			}
		})
	}
}

// The pull refusal is the one that must happen BEFORE the network round-trip:
// its no-ff mode sets the very field that skips the unborn fast-forward arm, so
// without the pre-flight it would fetch and then die on git's raw fatal.
func TestUnbornPullNoFFRefusesBeforeTheFetch(t *testing.T) {
	f := newUnbornRepo(t)
	remote := newRepo(t)
	testutil.Git(t, f.dir, "remote", "add", "origin", remote)

	_, stderr, code := runSafegit(t, f.dir, "pull", "--merge-strategy", "no-ff", "origin", "main")
	if code == 0 {
		t.Fatalf("pull --merge-strategy no-ff succeeded on an unborn branch\n%s", stderr)
	}
	for _, want := range []string{"unborn", "--merge-strategy no-ff"} {
		if !strings.Contains(stderr, want) {
			t.Errorf("refusal missing %q:\n%s", want, stderr)
		}
	}
	// The fetch never happened. FETCH_HEAD is no witness -- the fixture's own
	// `git fetch <src> main:side` wrote one -- so the evidence is the
	// remote-tracking ref this fetch would have created, and git's own "From
	// <remote>" narration.
	if _, ok := testutil.GitTryOut(t, f.dir, "rev-parse", "--verify", "--quiet", "refs/remotes/origin/main"); ok {
		t.Errorf("origin/main exists: the refusal came after the fetch")
	}
	if strings.Contains(stderr, "From "+remote) {
		t.Errorf("git narrated a fetch:\n%s", stderr)
	}
}

// oplogEntriesIfAny is oplogEntries over a repository that may have no oplog at
// all. A refusal that records nothing in a repository where no safegit
// operation ever recorded anything leaves no log file, and that absence is the
// answer rather than a failure to read.
func oplogEntriesIfAny(t *testing.T, dir, op string) []map[string]interface{} {
	t.Helper()
	if _, err := os.Stat(filepath.Join(dir, ".git", "safegit", "log")); err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		t.Fatalf("stat oplog: %v", err)
	}
	return oplogEntries(t, dir, op)
}

// assertRefusalRecorded checks the one entry a recorded refusal writes: a
// failed outcome and an EMPTY new tip. The empty tip is the mechanism rather
// than a formality -- the readers of the log take the newest entry for a ref
// that carries a new tip, so an entry with none is passed over and the position
// safegit really last left the branch at stays the one undo and doctor's bypass
// detection compare against.
func assertRefusalRecorded(t *testing.T, dir, op string) {
	t.Helper()
	entries := oplogEntriesIfAny(t, dir, op)
	if len(entries) != 1 {
		t.Fatalf("want exactly one %q oplog entry for the refusal, got %d: %v", op, len(entries), entries)
	}
	extra, _ := entries[0]["extra"].(map[string]interface{})
	if extra["outcome"] != "failed" {
		t.Errorf("outcome = %v, want \"failed\" (entry: %v)", extra["outcome"], entries[0])
	}
	if sha, _ := extra["sha"].(string); sha != "" {
		t.Errorf("sha = %q, want empty: the refused operation moved no ref", sha)
	}
}

// assertNothingRecorded checks that none of the named ops appears in the log.
func assertNothingRecorded(t *testing.T, dir string, ops ...string) {
	t.Helper()
	for _, op := range ops {
		if entries := oplogEntriesIfAny(t, dir, op); len(entries) != 0 {
			t.Errorf("op %q recorded %d oplog entry(ies), want none: %v", op, len(entries), entries)
		}
	}
}

// The oplog split across the friendly unborn refusals. It is NOT uniform, and
// the line is drawn by where each refusal sits rather than by how it reads.
//
// A refused unborn `merge --no-ff` / `merge --no-commit` and a refused unborn
// `pull --merge-strategy no-ff` are RECORDED: both sit past the point where the
// branch position was read, and what they record is a fact about where the
// branch stands -- the kind of thing an audit trail exists for -- rather than
// about what was typed. Each writes one entry with a failed outcome and no new
// tip.
//
// A refused unborn `rebase` and `bisect start` record NOTHING: their refusals
// come before any position is taken, deliberately so, and the operation never
// entered the recording path at all.
//
// Under `--dry-run` none of them records anything, because a preview writes no
// oplog in any case.
func TestUnbornRefusalOplogSplit(t *testing.T) {
	t.Run("merge --no-ff is recorded", func(t *testing.T) {
		f := newUnbornRepo(t)
		if stdout, stderr, code := runSafegit(t, f.dir, "merge", "--no-ff", "side"); code == 0 {
			t.Fatalf("merge --no-ff succeeded on an unborn branch\nstdout=%s\nstderr=%s", stdout, stderr)
		}
		assertRefusalRecorded(t, f.dir, "merge")
	})

	t.Run("merge --no-commit is recorded", func(t *testing.T) {
		f := newUnbornRepo(t)
		if stdout, stderr, code := runSafegit(t, f.dir, "merge", "--no-commit", "side"); code == 0 {
			t.Fatalf("merge --no-commit succeeded on an unborn branch\nstdout=%s\nstderr=%s", stdout, stderr)
		}
		assertRefusalRecorded(t, f.dir, "merge")
	})

	t.Run("pull --merge-strategy no-ff is recorded", func(t *testing.T) {
		f := newUnbornRepo(t)
		testutil.Git(t, f.dir, "remote", "add", "origin", newRepo(t))
		if stdout, stderr, code := runSafegit(t, f.dir, "pull", "--merge-strategy", "no-ff", "origin", "main"); code == 0 {
			t.Fatalf("pull --merge-strategy no-ff succeeded on an unborn branch\nstdout=%s\nstderr=%s", stdout, stderr)
		}
		assertRefusalRecorded(t, f.dir, "pull")
		// The refusal is the pull's own, before its merge step: no merge entry
		// rides along with it.
		assertNothingRecorded(t, f.dir, "merge")
	})

	t.Run("rebase records nothing", func(t *testing.T) {
		f := newUnbornRepo(t)
		if stdout, stderr, code := runSafegit(t, f.dir, "rebase", "side"); code == 0 {
			t.Fatalf("rebase succeeded on an unborn branch\nstdout=%s\nstderr=%s", stdout, stderr)
		}
		assertNothingRecorded(t, f.dir, "rebase")
	})

	t.Run("bisect start records nothing", func(t *testing.T) {
		f := newUnbornRepo(t)
		if stdout, stderr, code := runSafegit(t, f.dir, "bisect", "start"); code == 0 {
			t.Fatalf("bisect start succeeded on an unborn branch\nstdout=%s\nstderr=%s", stdout, stderr)
		}
		assertNothingRecorded(t, f.dir, "bisect")
	})

	t.Run("a preview of any of them records nothing", func(t *testing.T) {
		cases := []struct {
			name string
			args []string
			ops  []string
		}{
			{"merge --no-ff", []string{"--dry-run", "merge", "--no-ff", "side"}, []string{"merge"}},
			{"merge --no-commit", []string{"--dry-run", "merge", "--no-commit", "side"}, []string{"merge"}},
			{"pull --merge-strategy no-ff", []string{"--dry-run", "pull", "--merge-strategy", "no-ff", "origin", "main"}, []string{"pull", "merge"}},
			{"rebase", []string{"--dry-run", "rebase", "side"}, []string{"rebase"}},
			{"bisect start", []string{"--dry-run", "bisect", "start"}, []string{"bisect"}},
		}
		for _, tc := range cases {
			t.Run(tc.name, func(t *testing.T) {
				f := newUnbornRepo(t)
				testutil.Git(t, f.dir, "remote", "add", "origin", newRepo(t))
				if stdout, stderr, code := runSafegit(t, f.dir, tc.args...); code == 0 {
					t.Fatalf("--dry-run %v succeeded on an unborn branch\nstdout=%s\nstderr=%s", tc.args, stdout, stderr)
				}
				assertNothingRecorded(t, f.dir, tc.ops...)
			})
		}
	})
}

// A preview of a plain unborn merge answers without computing anything:
// merge-tree needs two commits and there is only one, and the answer is known
// by definition.
func TestUnbornMergePreviewShortCircuits(t *testing.T) {
	f := newUnbornRepo(t)

	stdout, stderr, code := runSafegit(t, f.dir, "--dry-run", "merge", "side")
	if code != 0 {
		t.Fatalf("--dry-run merge side on an unborn branch: code %d\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}
	if !strings.Contains(stdout, "fast-forward") {
		t.Errorf("preview does not report a fast-forward:\n%s", stdout)
	}
	if _, ok := testutil.GitTryOut(t, f.dir, "rev-parse", "--verify", "--quiet", "HEAD"); ok {
		t.Errorf("the preview created a commit")
	}
}

func TestUnbornCherryPickPreviewComputes(t *testing.T) {
	f := newUnbornRepo(t)

	stdout, stderr, code := runSafegit(t, f.dir, "--dry-run", "cherry-pick", f.firstSHA)
	if code != 0 {
		t.Fatalf("--dry-run cherry-pick on an unborn branch: code %d\nstdout=%s\nstderr=%s", code, stdout, stderr)
	}
	if !strings.Contains(stdout, "would cherry-pick") {
		t.Errorf("preview said nothing about the pick:\n%s", stdout)
	}
	if _, ok := testutil.GitTryOut(t, f.dir, "rev-parse", "--verify", "--quiet", "HEAD"); ok {
		t.Errorf("the preview created a commit")
	}
}
