package lock

import (
	"context"
	"os"
	"os/signal"
	"sync"
)

// heldLock is one lock this process still holds: where it is, and which file
// it published there. The identity travels with the path so that the
// no-unwind exit paths remove locks under the same rule RefLock.Release does
// -- see releaseIfOurs.
type heldLock struct {
	path      string
	published publication
}

var (
	cleanupMu    sync.Mutex
	pendingLocks []heldLock
	sigOnce      sync.Once
)

func registerCleanup(path string, published publication) {
	cleanupMu.Lock()
	pendingLocks = append(pendingLocks, heldLock{path: path, published: published})
	cleanupMu.Unlock()

	installSignalHandler()
}

// installSignalHandler installs this process's one SIGINT/SIGTERM handler: it
// cancels every InterruptHold, waits until each has been released, then
// releases the locks and exits. It is installed the first time a lock is taken
// or an interruptible section begins, and stays for the life of the process.
func installSignalHandler() {
	sigOnce.Do(func() {
		c := make(chan os.Signal, 1)
		signal.Notify(c, cleanupSignals()...)
		go func() {
			sig := <-c
			holdMu.Lock()
			received = sig
			for h := range holds {
				h.cancel()
			}
			for len(holds) > 0 {
				holdCond.Wait()
			}
			holdMu.Unlock()
			ExitOnSignal(sig)
		}()
	})
}

// ExitOnSignal ends a process a signal interrupted: it releases every lock the
// process still holds and exits 128 + the signal number, which is the
// convention every shell, supervisor and CI runner already reads (a SIGTERM is
// 143, a SIGINT 130). The number is not safegit's to choose, so it is an
// exception to the exit-code registry rather than a row in it -- stated in
// internal/exitcode's package doc beside the git-passthrough exception.
func ExitOnSignal(sig os.Signal) {
	ReleasePending()
	os.Exit(signalExitStatus(sig))
}

// SignalExitStatus is the exit status ExitOnSignal ends the process with: 128 +
// the signal number. It is for a section that ends the process through its own
// exit path instead, so that it can still write its answer (see InterruptHold).
func SignalExitStatus(sig os.Signal) int {
	return signalExitStatus(sig)
}

var (
	holdMu   sync.Mutex
	holdCond = sync.NewCond(&holdMu)
	holds    = map[*InterruptHold]struct{}{}
	// received is the signal that interrupted this process, nil until one does.
	received os.Signal
)

// InterruptHold is a section of work that a SIGINT or SIGTERM must interrupt
// rather than cut short: the signal cancels the section's context, and the
// process does not exit until the section is released or ends the process
// itself. Any further signal meanwhile is ignored: the handler has already
// taken the first one and is waiting on the section.
//
// A section ends the process itself either with ExitOnSignal or by returning
// SignalExitStatus through the command's own exit path, which is how it writes
// an answer first. It must then NOT release the hold: a release lets the
// handler exit under it before the answer is written.
//
// It exists for work that starts processes the signal never reaches -- a
// pre-pre-push hook runs in its own process group, so a terminal's Ctrl-C goes
// to safegit alone -- and that must therefore be stopped by safegit before it
// exits, not left running behind it.
type InterruptHold struct {
	cancel context.CancelFunc
}

// HoldInterrupts begins an interruptible section. The returned context is
// cancelled by a SIGINT or SIGTERM, including one that arrived earlier.
func HoldInterrupts(parent context.Context) (context.Context, *InterruptHold) {
	installSignalHandler()
	ctx, cancel := context.WithCancel(parent)
	h := &InterruptHold{cancel: cancel}
	holdMu.Lock()
	holds[h] = struct{}{}
	if received != nil {
		cancel()
	}
	holdMu.Unlock()
	return ctx, h
}

// Interrupted returns the signal that interrupted the process, if one did.
func (h *InterruptHold) Interrupted() (os.Signal, bool) {
	holdMu.Lock()
	defer holdMu.Unlock()
	return received, received != nil
}

// Release ends the section. A signal that arrived meanwhile then ends the
// process through the handler, so a section that was interrupted and means to
// end the process through its own exit path does not call it.
func (h *InterruptHold) Release() {
	holdMu.Lock()
	delete(holds, h)
	h.cancel()
	holdCond.Broadcast()
	holdMu.Unlock()
}

// ReleasePending removes every lock this process still holds.
//
// It is the backstop for a lock no deferred Release covers: every command
// handler runs it when it ends, after the deferred cleanup of everything it
// called, and the signal handler runs it before the process exits. Without it, a
// lock left behind would be waited out by the next contender and reported by
// doctor -- recoverable, since the holder is dead and the lock is therefore
// stale, but noise the process itself can prevent.
//
// It is safe to call when no lock is held, and safe to call twice.
//
// Each removal is identity-checked exactly as RefLock.Release is: a lock this
// process was force-released out of, and which another process has since
// re-taken, is left alone rather than deleted out from under its new holder.
func ReleasePending() {
	cleanupMu.Lock()
	defer cleanupMu.Unlock()
	for _, held := range pendingLocks {
		_ = releaseIfOurs(held.path, held.published)
	}
	pendingLocks = nil
}

func unregisterCleanup(path string) {
	cleanupMu.Lock()
	for i, p := range pendingLocks {
		if p.path == path {
			pendingLocks = append(pendingLocks[:i], pendingLocks[i+1:]...)
			break
		}
	}
	cleanupMu.Unlock()
}
