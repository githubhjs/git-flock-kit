// Package lock provides ref-lock primitives for concurrent ref updates using atomic lock file creation (link(2) of a fully-written temporary sibling) and exponential backoff polling.
// PID liveness checks detect and clean up stale locks left by crashed processes.
package lock

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/stricttools/safegit/internal/oplog"
	"github.com/stricttools/safegit/internal/procutil"
)

// The tool-owned pseudo-refs safegit locks under. They are not git refs and
// nothing ever resolves them as such: they are names in the same namespace as
// a ref so that one lock implementation serves both, and `safegit unlock`
// addresses them by these exact strings.
const (
	// RewriteRef is the repository-wide history-rewrite lock. It lives in the
	// SHARED safegit directory, so every worktree of the repository contends on
	// the same file: a rewrite changes object names for all of them. Taken by
	// scrub file, scrub match, scrub run and author rewrite.
	RewriteRef = "safegit/rewrite"

	// OperationRef is the worktree operation lock. It lives in the
	// WORKTREE-LOCAL safegit directory, so two worktrees of the same repository
	// operate independently while two processes in one worktree serialize.
	// Taken by every command that mutates this worktree: the guarded
	// passthroughs (switch, pull, merge, rebase, reset, bisect, cherry-pick,
	// revert) and the commit pipeline's three entry points plus undo.
	//
	// It is what makes a commit's in-flight-operation check meaningful. Without
	// it a passthrough could create sequencer state (a conflicted merge, a
	// stopped cherry-pick) in the window between a commit reading that state and
	// updating the ref, and the commit would build its tree against a repository
	// git considers mid-operation.
	OperationRef = "safegit/operation"
)

// Lock ordering, declared once for the whole tool.
//
// safegit takes at most two locks at a time, and always in this order:
//
//  1. OperationRef -- the worktree operation lock, OUTERMOST. A command that
//     takes it takes it first and holds it for its whole operation.
//  2. a per-ref lock (the commit pipeline's CAS lock on refs/heads/<branch>,
//     undo's lock on the same) or RewriteRef -- INSIDE.
//
// Nothing ever takes them the other way round, and nothing takes two locks at
// the same level. That is the entire deadlock argument: a total order over the
// two levels, with no cycle to close.
//
// One acquisition crosses REPOSITORIES, and it does not close a cycle either.
// A commit in a submodule (commit, amend, reword, mv, revert, undo, a
// conclusion) auto-bumps the parent's gitlink by spawning `safegit commit` in
// the PARENT worktree while still holding the submodule's own operation lock.
// So a submodule's operation lock can be held while the parent worktree's is
// acquired -- an edge from child to parent. Nothing ever acquires in the
// opposite direction: a commit in the parent never reaches into a submodule's
// operation lock, and the rewrite locks are a disjoint namespace taken strictly
// inside an operation lock rather than across one. The edge therefore runs one
// way through the submodule tree and there is no cycle.
//
// The consequence an operator meets: two sibling submodules bumping the same
// parent at the same time SERIALIZE on the parent's operation lock, and the one
// that waits out lock.acquireTimeoutSeconds fails its bump with
// exitcode.LockTimeout -- after its own commit has already been made, since the
// bump happens after it.
//
// The one consequence worth stating out loud: a passthrough holds the operation
// lock for the FULL duration of the git command it wraps, including an
// interactive `rebase -i`'s editor session. A second safegit process in the same
// worktree waits (lock.acquireTimeoutSeconds) and then refuses with
// exitcode.LockTimeout rather than running concurrently with a rebase.
//
// That editor does run -- verified, not assumed, by
// testdata/experiments/exp-passthrough-editor-stdin.sh. The passthroughs that go
// through the effects handle (switch, pull, merge, rebase, reset, bisect) give
// their git child /dev/null on stdin, so an editor that opens /dev/tty -- vim,
// nano, emacs -nw, every terminal editor -- works, while anything reading stdin
// sees EOF at once. The passthroughs that exec git directly (cherry-pick,
// revert) inherit stdin whole and have neither limitation.

// RefLock represents an acquired lock on a git ref.
type RefLock struct {
	Ref      string
	LockPath string
	// published identifies the file this process linked into place. Release
	// compares it against whatever is at LockPath before removing anything --
	// see releaseIfOurs.
	published publication
}

// publication is the identity of the lock file a process linked into place:
// the stat taken of that exact file before the link, and the owner record it
// carries.
//
// Both halves are needed, and the record is the half that actually decides.
// A stat identity is dev+inode, and a filesystem is free to hand a freed inode
// number straight back out: after a force-release, the newcomer's lock can
// land on the very inode this one had, and os.SameFile then says "ours" about
// somebody else's live lock. (ext4 does this routinely; btrfs, whose inode
// numbers only ever increase, does not -- which is why the hazard is invisible
// on one developer machine and reproducible on another.) A lock file is
// immutable once published, so comparing the bytes settles it.
type publication struct {
	info   os.FileInfo
	record string
}

// TimeoutError is what Acquire returns when the timeout expired with a live
// holder still owning the lock. It is a distinct type because the exit code
// safegit reports for that outcome (exitcode.LockTimeout) is distinct: a
// caller decides between "someone else is working here, wait or investigate"
// and every other reason a lock could not be taken by asking errors.As for
// this type, never by matching the message text.
//
// The message names the ref and the holder record, so a caller that surfaces
// the error verbatim tells the operator which process to look at.
type TimeoutError struct {
	// Ref is the ref (or the tool-owned pseudo-ref, e.g. safegit/rewrite)
	// whose lock could not be taken.
	Ref string
	// Holder is the lock file's owner record as describeHolder renders it.
	Holder string
	// Timeout is how long Acquire waited before giving up.
	Timeout time.Duration
}

func (e *TimeoutError) Error() string {
	return fmt.Sprintf("timeout acquiring lock on %s (held by %s)", e.Ref, e.Holder)
}

// IsTimeout reports whether err is, or wraps, a lock acquisition timeout.
func IsTimeout(err error) bool {
	var te *TimeoutError
	return errors.As(err, &te)
}

// backoff steps for polling: 10ms, 20ms, 50ms, 100ms, 200ms, 500ms, capped at 1s.
var backoffSteps = []time.Duration{
	10 * time.Millisecond,
	20 * time.Millisecond,
	50 * time.Millisecond,
	100 * time.Millisecond,
	200 * time.Millisecond,
	500 * time.Millisecond,
	1 * time.Second,
}

// lockDir returns the path to the lock directory for a given ref.
// ref is expected to be like "refs/heads/main" -> locks dir is locks/refs/heads/.
// locksBaseDir is the safegit directory that contains the "locks/" subtree;
// for worktrees this should be the shared (common) safegit dir.
func lockDir(locksBaseDir, ref string) string {
	return filepath.Join(locksBaseDir, "locks", filepath.Dir(ref))
}

// lockSuffix is the extension every lock file carries. A file under a locks/
// subtree is a lock if and only if its name ends in this.
const lockSuffix = ".lock"

// lockPath returns the full path to the lock file for a ref.
// e.g. refs/heads/main -> <locksBaseDir>/locks/refs/heads/main.lock
func lockPath(locksBaseDir, ref string) string {
	dir := lockDir(locksBaseDir, ref)
	base := filepath.Base(ref) + lockSuffix
	return filepath.Join(dir, base)
}

// Path returns where the lock file for ref lives under locksBaseDir. Callers
// that inspect or remove a lock by name -- `safegit unlock`, doctor -- resolve
// it here rather than rebuilding the path themselves.
func Path(locksBaseDir, ref string) string { return lockPath(locksBaseDir, ref) }

// NameFromPath is Path's inverse: it turns an absolute lock-file path under
// locksBaseDir back into the ref (or pseudo-ref) it locks, for display. A path
// outside that subtree, or one that is not a lock file, yields "".
func NameFromPath(locksBaseDir, path string) string {
	rel, err := filepath.Rel(filepath.Join(locksBaseDir, "locks"), path)
	if err != nil || strings.HasPrefix(rel, "..") {
		return ""
	}
	if !IsLockFile(filepath.Base(rel)) {
		return ""
	}
	return filepath.ToSlash(strings.TrimSuffix(rel, lockSuffix))
}

// Acquire attempts to acquire a lock on the given ref.
// locksBaseDir is the safegit directory whose "locks/" subtree holds lock files;
// for worktrees this should be the shared (common) safegit dir so that all
// worktrees serialize on the same lock. safegitDir is the worktree-local
// safegit dir used for oplog writes (stale-lock recovery events), which record
// sessionID, the Claude Code session handshake the command layer read.
// Creation is atomic, so exactly one caller wins it. If the lock is held by a
// dead process, it is automatically replaced -- see the reclamation rules in
// reclaim.go, which are what keep two contenders facing the same stale lock
// from both deciding they reclaimed it. Uses exponential backoff polling
// bounded by timeout.
func Acquire(locksBaseDir, safegitDir, ref, op, sessionID string, timeout time.Duration) (*RefLock, error) {
	lp := lockPath(locksBaseDir, ref)

	// Ensure the lock directory exists
	if err := os.MkdirAll(filepath.Dir(lp), 0755); err != nil {
		return nil, fmt.Errorf("creating lock dir: %w", err)
	}

	deadline := time.Now().Add(timeout)
	step := 0
	var seenHolder holderIdentity

	for {
		published, err := tryCreate(lp, op)
		if err == nil {
			registerCleanup(lp, published)
			return &RefLock{Ref: ref, LockPath: lp, published: published}, nil
		}

		if !errors.Is(err, os.ErrExist) {
			return nil, fmt.Errorf("creating lock file: %w", err)
		}

		// Lock file exists -- reclaim it only if its holder is genuinely gone.
		//
		// IsStale here is a cheap pre-filter that keeps the common contended
		// case (a live holder) off the flock path entirely. It is NOT what
		// authorizes the removal: two contenders can both pass it on the same
		// stale lock, and if both then removed the path, the second would
		// delete the fresh lock the first had already created and both would
		// believe they held the ref. The judgement that authorizes removal is
		// re-made inside reclaimLocked, under the lock file's own flock and
		// against the descriptor's inode.
		if IsStale(lp) {
			f, outcome := openForReclaim(lp)
			if f != nil {
				var stalePid int
				// os.Remove, not a minted removal: the acquire path is not a
				// command's declared effect, it is the contention handling
				// underneath every one of them.
				outcome, stalePid = reclaimLocked(f, lp, os.Remove)
				if outcome == reclaimDone {
					_ = oplog.Append(safegitDir, sessionID, oplog.Entry{
						Op: "lock_recovered",
						Extra: map[string]interface{}{
							"ref":      ref,
							"stalePid": stalePid,
						},
					})
					continue
				}
			}
			// Nothing was removed. A restart is worth taking immediately only
			// while there is still time; past the deadline fall through to the
			// timeout below rather than looping.
			if outcome == reclaimRestart && time.Now().Before(deadline) {
				continue
			}
		}

		// Not stale -- wait with backoff
		if time.Now().After(deadline) {
			return nil, &TimeoutError{Ref: ref, Holder: describeHolder(lp), Timeout: timeout}
		}

		// A lock that changed hands since the last poll is a lock being handed
		// around quickly, and the right response is to poll quickly again. This
		// is not a refinement: without it a busy lock starves its waiters. Every
		// waiter escalates to the 1s cap within six polls and stays there, so a
		// lock held for 30ms at a time sits idle for most of every second and
		// the queue drains at roughly one waiter per second however many are
		// waiting. Fifty concurrent commits then take fifty seconds and time out
		// on a lock whose total work is under two.
		//
		// The escalation still does its job where it was meant to: a lock held
		// by ONE process for minutes -- an interactive rebase -- never changes
		// hands, so its waiters keep escalating and poll once a second.
		if holder := readHolderIdentity(lp); holder.changedFrom(seenHolder) {
			seenHolder = holder
			step = 0
		}

		delay := backoffSteps[step]
		if step < len(backoffSteps)-1 {
			step++
		}
		// Don't sleep past deadline
		remaining := time.Until(deadline)
		if delay > remaining {
			delay = remaining
		}
		time.Sleep(delay)
	}
}

// holderIdentity identifies the file currently at a lock path well enough to
// tell "still the same holder" from "somebody else's lock now".
//
// The inode is what actually distinguishes them: every lock is published by
// linking a fresh temporary file into place, so a new holder is always a new
// inode. The size and modification time are carried as corroboration for
// filesystems that recycle inode numbers quickly.
type holderIdentity struct {
	known bool
	ino   uint64
	size  int64
	mod   time.Time
}

// readHolderIdentity identifies whatever is at path right now. A path that
// cannot be stat'ed yields an unknown identity, which compares as "changed"
// against a known one -- the lock disappearing is itself a change worth polling
// quickly after.
func readHolderIdentity(path string) holderIdentity {
	info, err := os.Stat(path)
	if err != nil {
		return holderIdentity{}
	}
	return holderIdentity{known: true, ino: inodeOf(info), size: info.Size(), mod: info.ModTime()}
}

// changedFrom reports whether this identity is a different lock file from prev.
// The first observation is not a change: there is nothing to compare against.
func (h holderIdentity) changedFrom(prev holderIdentity) bool {
	if !prev.known {
		return h.known
	}
	if !h.known {
		return true
	}
	return h.ino != prev.ino || h.size != prev.size || !h.mod.Equal(prev.mod)
}

// tryCreate creates the lock file with its owner record already in it, failing
// with os.ErrExist when someone else holds the lock. On success it returns the
// FileInfo of the file it published, which -- the publication being a link(2)
// of that exact file -- is the identity of whatever now sits at path. Release
// compares against it rather than removing the path blind.
//
// The stat is taken from the temporary sibling BEFORE the link, not from the
// path after it: a stat of the path could already be describing somebody
// else's lock if this one were force-released in between, and recording that
// identity would authorize removing THEIR lock later. Failing here costs
// nothing, because nothing has been published yet.
//
// The record is written to a temporary sibling and published with link(2)
// rather than written in place after an O_CREAT|O_EXCL open. Both give the same
// atomic "one winner" property against a competing creator, but only the link
// makes the file's CONTENT atomic too: with the in-place form the file exists,
// empty, for the instant between the open and the write, and a contender that
// reads it in that instant finds no pid= line, judges the lock a crashed
// holder's leftover, and removes a lock whose owner is very much alive. link(2)
// publishes a file that is already complete, so no reader ever sees a half-made
// lock.
//
// The owner record includes start=, the holder's process start identity, which
// is what lets a later staleness check tell the original holder apart from an
// unrelated process that inherited its PID. When the platform cannot report a
// start time the field is omitted and reuse detection is simply absent (see
// IsStale). started= is the same instant in human-readable form and carries no
// decision.
func tryCreate(path, op string) (publication, error) {
	tmp, err := os.CreateTemp(filepath.Dir(path), publicationTempPrefix(filepath.Base(path)))
	if err != nil {
		return publication{}, fmt.Errorf("creating temporary lock file: %w", err)
	}
	tmpName := tmp.Name()
	// The temp name is unlinked whichever way this goes: on success the lock
	// lives at path under its own link, on failure nothing is left behind.
	defer os.Remove(tmpName)

	record, err := writeLockContent(tmp, op)
	if err != nil {
		tmp.Close()
		return publication{}, err
	}
	if err := tmp.Chmod(0644); err != nil {
		tmp.Close()
		return publication{}, err
	}
	if err := tmp.Close(); err != nil {
		return publication{}, err
	}

	info, err := os.Stat(tmpName)
	if err != nil {
		return publication{}, fmt.Errorf("identifying the lock file before publishing it: %w", err)
	}

	// link(2) fails with EEXIST when path already exists, which is the same
	// atomic "one winner" property O_CREAT|O_EXCL gives, and Acquire reads that
	// error as "someone else holds it".
	if err := os.Link(tmpName, path); err != nil {
		return publication{}, err
	}
	return publication{info: info, record: record}, nil
}

// publicationTempInfix is what tryCreate appends to a lock's own base name to
// build the temporary sibling it publishes that lock from. os.CreateTemp then
// appends random digits, so a temp name can never end in lockSuffix.
const publicationTempInfix = ".tmp-"

// publicationTempPrefix is the name prefix tryCreate gives that temporary
// sibling: a leading dot (so the file is hidden and is not a lock by name)
// followed by the lock's own base name and the infix.
//
// It exists so the writer and every reader agree on one spelling: doctor's lock
// walk must never mistake one of these for a lock, and doctor's cleanup must be
// able to recognize one that a kill between creation and publication left
// behind.
func publicationTempPrefix(lockBase string) string {
	return "." + lockBase + publicationTempInfix
}

// IsLockFile reports whether name (a bare file name, not a path) names a lock.
// It is the predicate every scan of a locks/ subtree uses.
func IsLockFile(name string) bool {
	return strings.HasSuffix(name, lockSuffix) && !IsPublicationTemp(name)
}

// IsPublicationTemp reports whether name (a bare file name, not a path) is a
// lock-publication temporary sibling rather than a lock.
func IsPublicationTemp(name string) bool {
	return strings.HasPrefix(name, ".") && strings.Contains(name, lockSuffix+publicationTempInfix)
}

// lockContent builds the owner record a lock file carries. It is returned
// rather than written straight out because the publication keeps a copy: the
// record is the half of the lock's identity that survives inode reuse.
func lockContent(op string) string {
	hostname, _ := os.Hostname()
	content := fmt.Sprintf("pid=%d\nts=%s\nop=%s\nhost=%s\n",
		os.Getpid(),
		time.Now().UTC().Format(time.RFC3339Nano),
		op,
		hostname,
	)
	if start, startErr := procutil.StartTime(os.Getpid()); startErr == nil {
		content += fmt.Sprintf("start=%d\n", start.Ticks)
		if !start.Wall.IsZero() {
			content += fmt.Sprintf("started=%s\n", start.Wall.Format(time.RFC3339Nano))
		}
	}
	return content
}

// writeLockContent writes the owner record into an open lock file and returns
// the exact bytes it wrote.
func writeLockContent(f *os.File, op string) (string, error) {
	content := lockContent(op)
	_, err := f.WriteString(content)
	return content, err
}

// Release removes the lock file this process published, and nothing else.
func (l *RefLock) Release() error {
	unregisterCleanup(l.LockPath)
	return releaseIfOurs(l.LockPath, l.published)
}

// releaseIfOurs removes path only while it still names the exact file
// published identifies. It is the single removal path for a holder releasing
// its OWN lock -- RefLock.Release and ReleasePending both go through it.
//
// Removing by path alone is wrong in one reachable situation: an operator runs
// `safegit unlock <ref>` against a lock this process still holds (a
// force-release is deliberately unconditional -- it is the recovery path of
// last resort), a third process then wins the free path and publishes its own
// live lock there, and this process finally finishes and removes the path. The
// newcomer's lock is deleted while the newcomer is still working, and two
// operations mutate the ref at once -- the exact failure the lock exists to
// prevent.
//
// A mismatch therefore means our lock is already gone: someone force-released
// it. There is nothing to remove and nothing to report -- the removal we would
// have performed has already happened, and the file at the path belongs to
// somebody else. Silence is the whole response.
//
// The identity is the stat AND the owner record, because the stat alone is not
// proof. A filesystem may hand a freed inode number straight back out, so the
// newcomer's lock can occupy the exact dev+inode this one had and os.SameFile
// then answers "ours" about somebody else's live lock -- the very deletion this
// function exists to prevent, reappearing through the check meant to stop it.
// A lock file's record is written before publication and never modified after,
// so comparing the bytes on disk against the ones we wrote settles ownership
// where the inode number cannot.
//
// The residual window is between the read and the remove: the force-release
// plus the newcomer's publication would have to fall inside those two syscalls.
// Closing it entirely would mean flock, and an flock that cannot be taken (a
// filesystem without it, a contender mid-reclaim) would leave a holder unable
// to release its own lock at all -- a worse failure, and a much likelier one,
// than the window it removes.
func releaseIfOurs(path string, published publication) error {
	if published.info == nil {
		// Acquire is the only constructor of a held lock and always records
		// this, so a zero publication here is a RefLock somebody built by hand.
		// Refusing is the honest answer: removing blind is what this function
		// exists to stop, and pretending the release happened would strand the
		// lock.
		return fmt.Errorf("releasing %s: the lock carries no published identity", path)
	}
	current, err := os.Stat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	if !os.SameFile(published.info, current) {
		return nil
	}
	record, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}
	if string(record) != published.record {
		// Same inode number, different lock: the inode was reused under us.
		return nil
	}
	return os.Remove(path)
}

// IsStale reports whether the process that holds the lock file is dead, which
// is the only condition under which the lock may be reclaimed. An unreadable,
// corrupt or zero-length lock file (no parseable PID) is stale: it is what a
// crash mid-create leaves behind.
//
// There is no error return. Every condition this function can meet is already
// a verdict -- a lock it cannot read is stale, a comparison it cannot make
// fails closed and the lock is left alone -- so a caller has nothing to decide
// from an error that the boolean does not already say.
//
// Reclaiming a lock whose holder is still running lets two operations mutate
// the same ref at once, so every check beyond plain PID liveness must have
// positive evidence before it declares a lock stale:
//   - If the lock contains a host= field that differs from the local hostname,
//     refuse to reclaim (the PID belongs to a different machine's namespace).
//   - PID reuse is decided by comparing the start identity recorded at acquire
//     time against the current start time of whatever now holds that PID: a
//     mismatch means the recorded holder is gone and an unrelated process
//     inherited its PID. Nothing else -- and in particular no file timestamp --
//     is evidence of reuse. When either side of the comparison is missing
//     (no start= field, or a platform that cannot report start times) the check
//     fails closed and the lock is left alone.
func IsStale(path string) bool {
	f, err := os.Open(path)
	if err != nil {
		// Unreadable lock -- treat as stale
		return true
	}
	defer f.Close()

	stale, _ := staleFile(f, path)
	return stale
}

// staleFile is IsStale's judgement applied to an already-open lock file,
// returning the verdict and the holder's pid (0 when the file names none).
//
// Reading through the descriptor instead of re-opening path is what lets a
// reclaimer judge the exact file it holds open: between opening a lock file and
// deciding to remove it, another contender may have unlinked that file and
// created a different one at the same path, and a fresh read of the path would
// then judge -- and condemn -- the wrong file. See reclaimLocked.
func staleFile(f *os.File, path string) (bool, int) {
	if _, err := f.Seek(0, io.SeekStart); err != nil {
		return true, 0
	}
	fields, err := readLockFields(f)
	if err != nil {
		// Unreadable lock -- treat as stale
		return true, 0
	}
	pid, err := pidFromFields(fields, path)
	if err != nil {
		// Corrupt lock (e.g. zero-length from a crash mid-create) -- treat as stale
		return true, 0
	}
	return staleFromFields(fields, pid), pid
}

// staleFromFields decides staleness from already-parsed lock fields and the
// pid they name.
func staleFromFields(fields map[string]string, pid int) bool {
	// If lock has a host= field and it doesn't match this machine, the PID
	// check is meaningless (different PID namespace on NFS/shared FS).
	if lockHost := fields["host"]; lockHost != "" {
		localHost, hostErr := os.Hostname()
		if hostErr == nil && lockHost != localHost {
			return false
		}
	}

	if !procutil.ProcessAlive(pid) {
		return true // process does not exist
	}

	return pidWasReused(pid, fields["start"])
}

// pidWasReused reports whether the live process now occupying pid is a
// different process instance than the one that recorded recordedStart when it
// took the lock. Any inability to compare returns false: without evidence of
// reuse the holder is assumed to be alive and the lock stays.
func pidWasReused(pid int, recordedStart string) bool {
	if recordedStart == "" {
		return false
	}
	recorded, err := strconv.ParseUint(recordedStart, 10, 64)
	if err != nil {
		return false
	}
	current, err := procutil.StartTime(pid)
	if err != nil {
		return false
	}
	return current.Ticks != recorded
}

// ForceRelease unconditionally removes the lock file for a ref.
// locksBaseDir is the safegit directory whose "locks/" subtree holds lock files;
// for worktrees this should be the shared (common) safegit dir.
//
// remove performs the unlink, and it is a parameter for the same reason
// ReclaimIfStale's is: `safegit unlock` mints the removal through the effects
// handle, so releasing a lock is visible in machine mode and a preview records
// it instead of performing it. A remover that treats a missing path as success
// turns "there was no lock" into "the lock was released", so the caller's
// remover must report the absence -- os.Remove does.
func ForceRelease(locksBaseDir, ref string, remove func(string) error) error {
	lp := lockPath(locksBaseDir, ref)
	err := remove(lp)
	if os.IsNotExist(err) {
		return fmt.Errorf("no lock held on %s", ref)
	}
	return err
}

// parseLockFields reads a lock file's key=value lines. Every reader of a lock
// file goes through it, so the file's format is described in exactly one place.
// Unknown keys are kept; a line without '=' is ignored.
func parseLockFields(lockPath string) (map[string]string, error) {
	f, err := os.Open(lockPath)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return readLockFields(f)
}

// readLockFields parses lock-file lines from an already-open source, so a
// reader that holds a descriptor can parse the file it holds rather than
// whatever the path names by the time it looks again.
func readLockFields(r io.Reader) (map[string]string, error) {
	fields := make(map[string]string)
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		key, value, ok := strings.Cut(scanner.Text(), "=")
		if ok {
			fields[key] = value
		}
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return fields, nil
}

// pidFromFields extracts the pid from already-parsed lock fields.
func pidFromFields(fields map[string]string, lockPath string) (int, error) {
	pidStr, ok := fields["pid"]
	if !ok {
		return 0, fmt.Errorf("no pid= line in lock file %s", lockPath)
	}
	pid, err := strconv.Atoi(pidStr)
	if err != nil {
		return 0, fmt.Errorf("invalid pid in lock file: %q", pidStr)
	}
	return pid, nil
}

// ParsePID reads the lock file and extracts the pid= value.
func ParsePID(lockPath string) (int, error) {
	fields, err := parseLockFields(lockPath)
	if err != nil {
		return 0, err
	}
	return pidFromFields(fields, lockPath)
}

// describeHolder returns a human-readable description of the lock holder.
func describeHolder(lockPath string) string {
	fields, err := parseLockFields(lockPath)
	if err != nil {
		return "unknown"
	}
	return fmt.Sprintf("pid=%s op=%s host=%s started=%s",
		fields["pid"], fields["op"], fields["host"], fields["started"])
}
